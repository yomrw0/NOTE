package com.bit.note.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bit.note.model.dao.GameRoomMapper;
import com.bit.note.model.dto.GameRoom;
import com.bit.note.model.dto.Member;

@Controller
public class GameRoomController {
	
	@Autowired
	GameRoomMapper GM;
	
	@RequestMapping("/lobby")
	public String lobby(HttpSession session, Model model) {
		List<GameRoom> gameRoomList = GM.gameroom();
		model.addAttribute(gameRoomList);
		Member member = (Member) session.getAttribute("member");
		if(member==null) {
			return "redirect:/";
		}else {
			model.addAttribute("nick", member.getNickName());
			return "/lobby";
		}
	}
	
	/**
	 * 검색 ajax
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/search")
	@ResponseBody
	public List<GameRoom> search(HttpServletRequest request, Model model) {
		String roomName = request.getParameter("roomword");
		List<GameRoom> gameRoomList = GM.searchRoom(roomName);	
		return gameRoomList;
	}
	
	public void close(int intNumber) {
		GM.roomClose(intNumber);
	}

	@RequestMapping("/create")
	public String create(HttpSession session, @RequestParam("title") String title, 
			@RequestParam(name="lockCheck", required=false)boolean lockCheck, // 비밀번호가 있을 때 잠금방
			@RequestParam("password") String password, 
			@RequestParam(name="modeSelect", required=false)boolean modeSelect, 
			@RequestParam(name="selectTurn", required=false)boolean selectTurn) {
		System.out.println(title);
		System.out.println(lockCheck);
		System.out.println(password);
		System.out.println(modeSelect);
		System.out.println(selectTurn);
		
		GameRoom room = new GameRoom();
		room.setRoomNumber(GM.count()+1);
		Member member = (Member) session.getAttribute("member");
		room.setHost(member.getEmail());
		room.setRoomName(title);
		if(lockCheck) {
			room.setRoomPW(password);
		}else {
			room.setRoomPW("");
		}
		
		int roomNumber = room.getRoomNumber();
		String roomName = room.getRoomName();
		String roomPW = room.getRoomPW();
		String host = room.getHost();
		String status;
		if(modeSelect) {
			status = "ai";
		}else {
			status = "open";
		}
		
		GM.create(roomNumber, roomName, roomPW, host, status);

		if(modeSelect) { // ai 골랐을 때
			String guest = "AI";
			GM.update(roomNumber, guest);
			if(selectTurn) { // white
				return "redirect:/omokAI?roomNumber="+roomNumber+"&stone=white";
			}else { // black
				return "redirect:/omokAI?roomNumber="+roomNumber+"&stone=black";
			}
		}else { // 유저
			if(selectTurn) { // white
				return "redirect:/omok?roomNumber="+roomNumber+"&stone=white";
			}else { // black
				return "redirect:/omok?roomNumber="+roomNumber+"&stone=black";
			}
		}
	}
	
	
	/**
	 * 방 입장 - 게스트 유무 체크 ajax
	 */
	@RequestMapping(value="/guestOrNot",method=RequestMethod.POST)
	@ResponseBody
	public boolean guestOrNot(HttpServletRequest request) {
		int roomNumber = Integer.parseInt(request.getParameter("$gameRoomNumber"));
		String guest = GM.guestOrNot(roomNumber);
		System.out.println(guest);
		if(guest==null) {
			return true;
		}else {
			return false;
		}
		
	}
}
