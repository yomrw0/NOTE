package com.bit.note.model.dto;

import java.util.Date;

import lombok.Data;

@Data
public class Notice {
	private String title;
	private String writer;
	private String contents;
	private Date writeDate;
	private int noticeNumber;
}