package com.bit.note.controller;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.UriComponentsBuilder;

import com.bit.note.model.dao.MemberMapper;
import com.bit.note.model.dto.Member;
import com.bit.note.securityAPI.GoogleOAuthRequest;
import com.bit.note.securityAPI.GoogleOAuthResponse;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

@Controller
@SessionAttributes("member")
public class MemberController {
	final static String GOOGLE_AUTH_BASE_URL = "https://accounts.google.com/o/oauth2/v2/auth";
	final static String GOOGLE_TOKEN_BASE_URL = "https://oauth2.googleapis.com/token";
	final static String GOOGLE_REVOKE_TOKEN_BASE_URL = "https://oauth2.googleapis.com/revoke";

	String clientId = "299690057507-19leos8jg5jf6fak59nfrhcl4bt3tr56.apps.googleusercontent.com";
	String clientSecret = "yHw6_NHoN5CWbldyIbayQmAp";
	
	@Autowired
	MemberMapper MM;

	@RequestMapping("/")
	public String main(HttpSession session, SessionStatus sessionStatus) {
	
		return "main";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(Model model, String email, String pw, HttpSession session) {
		Member member = MM.login(email, pw);

		if (member == null) {

			model.addAttribute("msg", "로그인 실패!");
			return "main";
		} else {

			session.setAttribute("member", member);
			return "main";
		}
	}

	@RequestMapping("/join")
	public String join() {

		return "/join";
	}

	@RequestMapping("/listAll")
	public String listAll(Model model) {

		model.addAttribute("signUp", MM.listAll());
		return "/join";
	}

	@RequestMapping("/save")
	public String add(Member member, MultipartHttpServletRequest multipartHttpServletRequest) {
		
		MultipartFile multipartFile = multipartHttpServletRequest.getFile("file");

		try {
			member.setProfile(multipartFile.getBytes());

		} catch (Exception e) {
			e.printStackTrace();
		}
	
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime()); 
		

		member.setAccountDate(sqlDate);

		String email = member.getEmail();
		String pw = member.getPw();
		String nickName = member.getNickName();
		byte[] profile = member.getProfile();

		MM.insert(email, pw, nickName, sqlDate, profile);

		return "redirect:/";
	}
	
	@RequestMapping("/imgUpdate")
	public String imgUpdate(Member member, MultipartHttpServletRequest multipartHttpServletRequest) {
		
		MultipartFile multipartFile = multipartHttpServletRequest.getFile("file");

		try {
			member.setProfile(multipartFile.getBytes());

		} catch (Exception e) {
			e.printStackTrace();
		}

		String email = member.getEmail();
		byte[] profile = member.getProfile();

		MM.imgUpdate(email, profile);

		return "redirect:/";
	}

	@RequestMapping(value = "/getByteImage")
	public ResponseEntity<byte[]> getByteImage(HttpSession session) {

		byte[] imageContent = ((Member) session.getAttribute("member")).getProfile();

		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);

		return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getByteImageByEmail")
	public ResponseEntity<byte[]> getByteImageByEmail(String email) {

		byte[] imageContent = (MM.getHost(email)).getProfile();

		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);

		return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/emailCheck", method = RequestMethod.POST)
	public int checkEmail(HttpServletRequest request, Model model) {
		
		String email = request.getParameter("email");

		int rowcount = MM.emailCheck(email);
		
		return rowcount;
	}

	@ResponseBody
	@RequestMapping(value = "/nickNameCheck", method = RequestMethod.POST)
	public int checkNickName(HttpServletRequest request, Model model) {
		
		String nickName = request.getParameter("nickName");

		int rowcount = MM.nickNameCheck(nickName);
	
		return rowcount;
	}

	@RequestMapping("/updateForm")
	public String update(HttpSession session) {
		
		return "myPage";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(Member member, Model model, HttpSession session) {

		MM.update(member);
			
		session.setAttribute("member", member);
		
		return "main";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, SessionStatus sessionStatus) {
		session.removeAttribute("member");
		session.invalidate();
		sessionStatus.setComplete();
		
		return "redirect:/";
	}

	@RequestMapping("/delete")
	public String delete(HttpSession session, Member member) {
		MM.delete(member.getEmail());
		
		return "redirect:/logout";
	}
	
	@RequestMapping("/success")
    public String googleAuth(Model model, @RequestParam(value = "code")String authCode, HttpSession session) throws JsonProcessingException{
    	System.out.println("googleAuth");
    	
    	//HTTP Request를 위한 RestTemplate
    			RestTemplate restTemplate = new RestTemplate();

    			//Google OAuth Access Token 요청을 위한 파라미터 세팅
    			GoogleOAuthRequest googleOAuthRequestParam = GoogleOAuthRequest
    					.builder()
    					.clientId(clientId)
    					.clientSecret(clientSecret)
    					.code(authCode)
    					.redirectUri("http://localhost:9090/success")
    					.grantType("authorization_code").build();

    			
    			//JSON 파싱을 위한 기본값 세팅
    			//요청시 파라미터는 스네이크 케이스로 세팅되므로 Object mapper에 미리 설정해준다.
    			ObjectMapper mapper = new ObjectMapper();
    			mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
    			mapper.setSerializationInclusion(Include.NON_NULL);

    			//AccessToken 발급 요청
    			ResponseEntity<String> resultEntity = restTemplate.postForEntity(GOOGLE_TOKEN_BASE_URL, googleOAuthRequestParam, String.class);

    			//Token Request
    			GoogleOAuthResponse result = mapper.readValue(resultEntity.getBody(), new TypeReference<GoogleOAuthResponse>() {
    			});

    			//ID Token만 추출 (사용자의 정보는 jwt로 인코딩 되어있다)
    			String jwtToken = result.getIdToken();
    			String requestUrl = UriComponentsBuilder.fromHttpUrl("https://oauth2.googleapis.com/tokeninfo")
    			.queryParam("id_token", jwtToken).encode().toUriString();
    			
    			String resultJson = restTemplate.getForObject(requestUrl, String.class);
    			
    			Map<String,String> userInfo = mapper.readValue(resultJson, new TypeReference<Map<String, String>>(){});
    			model.addAllAttributes(userInfo);
    			model.addAttribute("token", result.getAccessToken());
    			
    			String email = null;
    			String name = null;
    			for (String mapkey : userInfo.keySet()){
    		        if(mapkey.equals("email")) {
    		        	email = userInfo.get(mapkey);
    		        }
    		        if(mapkey.equals("name")) {
    		        	name = userInfo.get(mapkey);
    		        }
    		    }
    			
    			int rowcount = MM.emailCheck(email);
    			if(rowcount==1) {
    				Member member = MM.loginEmail(email);
    				session.setAttribute("member", member);
    				return "main";
    			}else {
    				model.addAttribute("googleEmail", email);
    				model.addAttribute("googleNickName", name);
    				return "join";
    			}
    }
}
