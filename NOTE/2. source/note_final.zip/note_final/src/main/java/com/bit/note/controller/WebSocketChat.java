package com.bit.note.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint.Basic;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.bit.note.model.dao.GameRoomMapper;
import com.bit.note.model.dao.MemberMapper;
import com.bit.note.model.dto.Member;

/*@Controller*/
@Component
@ServerEndpoint(value="/chat", configurator = CustomSpringConfigurator.class)
public class WebSocketChat  {
	@Autowired
	GameRoomMapper GM;
	@Autowired
	MemberMapper MM;
	
    private static final Map<String, Session> channel = new HashMap<String, Session>();
    private static final Logger logger = LoggerFactory.getLogger(WebSocketChat.class);
    private String roomNumber;
    private boolean gameEnd = false;
    public WebSocketChat() {
        // TODO Auto-generated constructor stub
    	System.out.println("웹소켓(서버) 객체생성 /chat");
    }
    
    /**
     * 채팅방 연결 눌렀을 때 웹소켓 접속한다.
     * @param session
     */
    @OnOpen
    public void onOpen(Session session) {
        logger.info("Open session id:"+session.getId());
        System.out.println("Open session id:"+session.getId());
        System.out.println("omok에서 웹소켓에 연결되었습니다!!");
        try {
            final Basic basic=session.getBasicRemote();
            //basic.sendText("대화방에 연결 되었습니다.");
        }catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
        }
    }
    
    /**
     * 모든 사용자에게 메시지를 전달한다.
     * @param self
     * @param sender
     * @param message
     */
    private void sendAllSessionToMessage(Session self, String sender, String message, String roomN) {
    	System.out.println("send 옴");
    	
		String Key = getKey(channel, self);
        if(Key.contains("guest")) { // 게스트인가?
        	String hostKey = Key.split(",")[0];
        	Session hostSession = channel.get(hostKey);
        	Basic basic=hostSession.getBasicRemote();
        	Basic basic2 = self.getBasicRemote();
        	try {
				basic.sendText(message+"!@#**Guest");
				basic2.sendText(message+"!@#**Guest");
			} catch (IOException e) {
				e.printStackTrace();
			}
        }else { // 호스트인가?
        	String guestKey = Key+",guest";
        	Session guestSession = channel.get(guestKey);
        	Basic basic=guestSession.getBasicRemote();
        	Basic basic2 = self.getBasicRemote();
        	try {
				basic.sendText(message+"!@#**Host");
				basic2.sendText(message+"!@#**Host");
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
    }
    
    /**
     * 내가 입력하는 메세지
     * 메세지 + 센더 + 룸넘버
     * 센더 ==> 명령어로 사용
     */
    @OnMessage
    public void onMessage(String message,Session session) {
    	System.out.println("onMessage");
    	System.out.println(message);
    	String sender = message.split(",")[1];
    	String roomN = message.split(",")[2];
    	message = message.split(",")[0];
    	System.out.println("sender=="+sender+" message=="+message+"roomN=="+roomN);
    	
    	if(sender.equals("offerWSset")) { // onOpen 방생성 명령인가?
        	roomNumber = roomN;
        	if(channel.containsKey(roomNumber)) { // 게스트인가?
        		channel.put(roomNumber+",guest", session);
        		 System.out.println("onOpen, mapKey=="+roomNumber+".guest"+"session=="+session);
        		 	// 게스트 참여했다는 메세지 전송
        		 try {
					session.getBasicRemote().sendText("infoPlz");
					System.out.println("infoPlz");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}else { // 호스트인가? 호스트면 roomNumber 그대로
        		channel.put(roomNumber, session);
        		 System.out.println("onOpen, mapKey=="+roomNumber+"session=="+session);
        	        try { // 방 생성 명령일 때, 호스트면 게스트 인풋 막아라!
        	            session.getBasicRemote().sendText("blockGuest");
        	        }catch (Exception e) {
        	        }
        	}
 	
    	}else if(sender.equals("guestInfo")){
    		String InfoNick = message.split("~")[0];
    		String InfoEmail = message.split("~")[1];
    		String InfoWinLose = message.split("~")[2];
    		String guestKey = getKey(channel, session);
	        String hostKey = guestKey.split(",")[0];
	        Session hostSession = channel.get(hostKey);
	        try {
				hostSession.getBasicRemote().sendText("guestInfoBack*"+InfoNick+"*"+InfoEmail+"*"+InfoWinLose);
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}else if(sender.equals("FTC()")){
        	Basic basic2 = session.getBasicRemote();
        	try {
				basic2.sendText("FTC()");
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}else if(sender.equals("FTC(black)")) { // 호스트 턴 설정
    		String Key = getKey(channel, session);
    		String guestKey = Key+",guest";
        	Session guestSession = channel.get(guestKey);
        	Basic basic=guestSession.getBasicRemote();
        	Basic basic2 = session.getBasicRemote();
        	try {
				basic.sendText("FTC(black)");
				basic2.sendText("FTC(black)");
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}else if(sender.equals("FTC(white)")) { // 호스트 턴 설정
    		String Key = getKey(channel, session);
    		String guestKey = Key+",guest";
        	Session guestSession = channel.get(guestKey);
        	Basic basic=guestSession.getBasicRemote();
        	Basic basic2 = session.getBasicRemote();
        	try {
				basic.sendText("FTC(white)");
				basic2.sendText("FTC(white)");
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}else if(sender.equals("panclick()")){ // 판 클릭
    		String Key = getKey(channel, session);
            if(Key.contains("guest")) { // 게스트인가?
            	String hostKey = Key.split(",")[0];
            	Session hostSession = channel.get(hostKey);
            	Basic basic=hostSession.getBasicRemote();
            	Basic basic2 = session.getBasicRemote();
            	try {
    				basic.sendText("panclick()&*&"+message);
    				basic2.sendText("panclick()&*&"+message);
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
            }else { // 호스트인가?
            	String guestKey = Key+",guest";
            	Session guestSession = channel.get(guestKey);
            	Basic basic=guestSession.getBasicRemote();
            	Basic basic2 = session.getBasicRemote();
            	try {
    				basic.sendText("panclick()&*&"+message);
    				basic2.sendText("panclick()&*&"+message);
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
            }
    	}else if(sender.equals("gameEnd()")){
    		gameEnd = true;
    		String winStone = message.split("~")[0];
    		String hostStone = message.split("~")[1];
    		int roomNumber = Integer.parseInt(roomN);
    		String hostEmail = GM.getHost(roomNumber);
    		String guestEmail = GM.getGuest(roomNumber);
    		if(winStone.equals(hostStone)) { // 승자 = 호스트
    			System.out.println("호스트 승");
    			MM.win(hostEmail);
    			MM.lose(guestEmail);
    		}else { // 승자 = 게스트
    			System.out.println("게스트 승");
    			MM.win(guestEmail);
    			MM.lose(hostEmail);
    		}
    	}else { // 정상적인 메세지 전송
            sendAllSessionToMessage(session, sender, message, roomN);
    	}
    	
    }
    
    @OnError
    public void onError(Throwable e,Session session) {
        System.out.println(e);
        System.out.println(e.toString());
        System.out.println(e.getCause());
    }
    
    @OnClose
    public void onClose(Session session) {
        logger.info("Session "+session.getId()+" has ended");
        System.out.println("Session "+session.getId()+" has ended");
      String Key = getKey(channel, session);
      
      if(gameEnd) { // 게임 끝나고 퇴장? OK
      System.out.println("게임 끝!");
      }else if(channel.containsKey(roomNumber+",guest")==false) { // 게스트 없을 때 퇴장? OK
          System.out.println("시작 전 게임 끝!");
      }else { // 게임 안 끝남 -> 탈주
           if(Key.contains("guest")) { // 게스트인가?
              System.out.println("게스트 탈주");
              String hostKey = Key.split(",")[0];
               String roomN = roomNumber;
             int roomNumber = Integer.parseInt(roomN);
             String hostEmail = GM.getHost(roomNumber);
             String guestEmail = GM.getGuest(roomNumber);
             MM.win(hostEmail);
             MM.lose(guestEmail);
               Session hostSession = channel.get(hostKey);
               Basic basic=hostSession.getBasicRemote();
               try {
                basic.sendText("gameEnd()");
             } catch (IOException e) {
                e.printStackTrace();
             }
             
           }else { // 호스트인가?
             System.out.println("호스트 탈주");
             String roomN = roomNumber;
             int roomNumber = Integer.parseInt(roomN);
             String hostEmail = GM.getHost(roomNumber);
             String guestEmail = GM.getGuest(roomNumber);
             MM.win(guestEmail);
             MM.lose(hostEmail);
               String guestKey = Key+",guest";
               Session guestSession = channel.get(guestKey);
               Basic basic=guestSession.getBasicRemote();
               try {
                basic.sendText("gameEnd()");
             } catch (IOException e) {
                e.printStackTrace();
             }
           }
      }
      if(Key.contains("guest")) {
           String hostKey = Key.split(",")[0];
           int intNumber = Integer.parseInt(hostKey);
            GM.roomClose(intNumber);
      }else {
          int intNumber = Integer.parseInt(Key);
           GM.roomClose(intNumber);
      }
       channel.remove(roomNumber+",guest");
       channel.remove(roomNumber);
    }
        
    public static <K, V> K getKey(Map<K, V> map, V value) {
    	 
        for (K key : map.keySet()) {
            if (value.equals(map.get(key))) {
                return key;
            }
        }
        return null;
    }
    
}