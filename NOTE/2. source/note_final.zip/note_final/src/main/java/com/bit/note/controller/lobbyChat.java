package com.bit.note.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint.Basic;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.bit.note.model.dao.GameRoomMapper;
import com.bit.note.model.dao.MemberMapper;
import com.bit.note.model.dto.Member;

@Controller
@ServerEndpoint(value="/lobby")
public class lobbyChat {
	@Autowired
	GameRoomMapper GM;
	@Autowired
	MemberMapper MM;
	
	private static final Map<String, Session> connector = new HashMap<String, Session>();
    private static final List<Session> sessionList=new ArrayList<Session>();;
    private static final Logger logger = LoggerFactory.getLogger(lobbyChat.class);
    public lobbyChat() {
        // TODO Auto-generated constructor stub
    	System.out.println("웹소켓(서버) 객체생성 /lobby");
    }

    /**
     * 채팅방 연결 눌렀을 때 웹소켓 접속한다.
     * @param session
     */
    @OnOpen
    public void onOpen(Session session) {
        logger.info("Open session id:"+session.getId());
        System.out.println("Open session id:"+session.getId());
        try {
            final Basic basic=session.getBasicRemote();
            basic.sendText("대화방에 연결 되었습니다.");
            basic.sendText("give*Me*Nick");
        }catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
        }
        sessionList.add(session);
    }
    
    /**
     * 모든 사용자에게 메시지를 전달한다.
     * @param self
     * @param sender
     * @param message
     */
    private void sendAllSessionToMessage(Session self, String sender, String message) {
    	System.out.println("sendAllSessionToMessage");

        try {
            for(Session session : lobbyChat.sessionList) {
                if(!self.getId().equals(session.getId())) {
                    session.getBasicRemote().sendText(sender+" : "+message);
                }
            }
        }catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
            System.out.println("error");
            System.out.println(e.toString());
        }
    }
    
    /**
     * 내가 입력하는 메세지
     * @param message
     * @param session
     */
    @OnMessage
    public void onMessage(String message,Session session) {
    	System.out.println("onMessage");
    	
    	String sender = message.split(",")[1];
    	message = message.split(",")[0];
    	
    	if(sender.equals("ConnectIn")) {
    		connector.put(message, session);
    		try {
    			String connListString = "";
    			int connListSize = 0;
                for(String Key : connector.keySet()) {
                	System.out.println("nick=="+Key+"Session=="+connector.get(Key));
                	connListString += Key+",";
                	connListSize++;
                }
                for(Session allSession : lobbyChat.sessionList) {
                	System.out.println(connListString);
                	System.out.println(connListSize);
                	allSession.getBasicRemote().sendText("ConnNick,"+connListSize+","+connListString);
                }
            }catch (Exception e) {
                // TODO: handle exception
                System.out.println(e.getMessage());
                System.out.println("error");
                System.out.println(e.toString());
            }
    	}
    	else {
    	logger.info("Message From "+sender + ": "+message);
            try {
                final Basic basic=session.getBasicRemote();
                //System.out.println(basic);
                basic.sendText(sender + " : "+message);
            }catch (Exception e) {
                // TODO: handle exception
                System.out.println(e.getMessage());
            }
            sendAllSessionToMessage(session, sender, message);
    	}
    }
    
    @OnError
    public void onError(Throwable e,Session session) {
        System.out.println(e);
        System.out.println(e.toString());
        System.out.println(e.getCause());
    }
    
    @OnClose
    public void onClose(Session session) {
        logger.info("Session "+session.getId()+" has ended");
        System.out.println("Session "+session.getId()+" has ended");
        sessionList.remove(session);
        connector.remove(getKey(connector, session));
        
        try {
			String connListString = "";
			int connListSize = 0;
            for(String Key : connector.keySet()) {
            	System.out.println("nick=="+Key+"Session=="+connector.get(Key));
            	connListString += Key+",";
            	connListSize++;
            }
            for(Session allSession : lobbyChat.sessionList) {
            	System.out.println(connListString);
            	System.out.println(connListSize);
            	allSession.getBasicRemote().sendText("ConnNick,"+connListSize+","+connListString);
            }
        }catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
            System.out.println("error");
            System.out.println(e.toString());
        }
    }
    
    public static <K, V> K getKey(Map<K, V> map, V value) {
   	 
        for (K key : map.keySet()) {
            if (value.equals(map.get(key))) {
                return key;
            }
        }
        return null;
    }

}