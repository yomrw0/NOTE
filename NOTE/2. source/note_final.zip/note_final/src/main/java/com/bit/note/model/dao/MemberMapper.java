package com.bit.note.model.dao;

import java.sql.Date;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.bit.note.model.dto.Member;

@Mapper
public interface MemberMapper {
	
	@Select("SELECT count(email) FROM member where email=#{email}")
	int emailCheck(String email);
	
	@Select("SELECT count(nickName) FROM member where nickName=#{nickName}")
	int nickNameCheck(String nickName);
	
	@Select("SELECT * FROM member")
    List<Member> listAll();
    
    @Update("Update member m set m.pw=#{pw}, m.nickName=#{nickName} where m.email=#{email}")
	void update (Member member);
	
    @Update("Update member m set m.profile=#{profile} where m.email=#{email}")
	void imgUpdate (String email, byte[] profile);
    
    @Delete("Delete from member where email=#{email}")
    void delete (String email);

    @Select("Select * from member where email=#{email} and pw=#{pw}")
    Member login(@Param("email") String email, @Param("pw") String pw);
    
    @Select("Select * from member where email=#{email}")
    Member loginEmail(@Param("email") String email);

    @Select("Select * from member where email=#{email}")
    Member getByteImage(@Param("email") String email);
   
    @Select("Select profile from member where nickname=#{nickname}")
    byte[] getByteImage2(@Param("nickname") String nickname);
    
    @Insert("INSERT INTO member(email, pw, nickname, accountdate, profile, rating, win, lose) VALUES (#{email}, #{pw}, #{nickName}, #{accountDate}, #{profile}, 1000, 0, 0)")
    void insert(String email, String pw, String nickName, Date accountDate, byte[] profile);
    
    @Select("Select * from member where email=#{email}")
    Member getHost(String email);	
    
    @Select("Select * from member where email=#{message}")
    Member senderCheck(@Param("message") String message);
    
    @Update("Update member m set m.RATING = m.RATING+10, m.WIN = m.WIN+1 where m.email=#{email}")
	void win (String email);
    
    @Update("Update member m set m.RATING = m.RATING-10, m.LOSE = m.LOSE+1 where m.email=#{email}")
	void lose (String email);
}
