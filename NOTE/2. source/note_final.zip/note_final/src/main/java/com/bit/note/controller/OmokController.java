package com.bit.note.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bit.note.model.dao.GameRoomMapper;
import com.bit.note.model.dao.MemberMapper;
import com.bit.note.model.dto.Member;

@Controller
public class OmokController {

	private static final Map<Omok, String> channel = new HashMap<Omok, String>();
	
	@Autowired
	GameRoomMapper GM;
	@Autowired
	MemberMapper MM;
	
	@RequestMapping("/omok")
	public String hostRoom(HttpSession session, Model model, int roomNumber, String stone) {
		Member member = (Member) session.getAttribute("member");
		List<Member> gameMember = new ArrayList<>();
		gameMember.add(0, member);
		Member guest = new Member();
		gameMember.add(1, guest);
		model.addAttribute("gameMember", gameMember);
		model.addAttribute("hostStone", stone);
		model.addAttribute("roomNumber", roomNumber);
		model.addAttribute("who", member.getEmail());
		return "omok";
	}
	
	@RequestMapping("/omokGuest")
	public String guestJoin(HttpSession session, Model model, int roomNumber) {
		Member member = (Member) session.getAttribute("member");
		List<Member> gameMember = new ArrayList<>();
		Member host = MM.getHost(GM.getHost(roomNumber));
		gameMember.add(0, host);
		gameMember.add(1, member);
		model.addAttribute("gameMember", gameMember);
		model.addAttribute("roomNumber", roomNumber);
		model.addAttribute("who", member.getEmail());
		GM.update(roomNumber, member.getEmail());
		return "omok";
	}
	
	@RequestMapping("/omokAI")
	public String omokAI(HttpSession session, Model model, int roomNumber, String stone) {
		Member member = (Member) session.getAttribute("member");
		if(member!=null) {
		BufferedImage image = null;
		model.addAttribute("member", member);
		byte[] profile = member.getProfile();
		ByteArrayInputStream bais = new ByteArrayInputStream(profile);
		try {
			image = ImageIO.read(bais);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("hostStone", stone);
		
		model.addAttribute("profile", image);
		//String base64EncodedImage = Base64.encodeBase64String(member.getProfile());
		return "omokAI"; 
		}
		else {
			return "redirect:/";
		}
	}
		
	/**
	 * 인스턴스 생성하고 필드상황 불러오는 ajax
	 */
	@RequestMapping(value="/register",method=RequestMethod.POST)
	@ResponseBody
	public int[][] register(HttpServletRequest request) {
		String msg = request.getParameter("msg");
		int userTurn = Integer.parseInt(msg.split(",")[0]);
		int AITurn = Integer.parseInt(msg.split(",")[1]);
		String Session = msg.split(",")[2];
		Omok omok = new Omok();
		omok.userTurn = userTurn;
		omok.AITurn = AITurn;
		System.out.println(omok);
		channel.put(omok, Session);
		return field(omok);
	}
	
	/**
	 * 필드 상황 불러오는 메소드
	 */
	public int[][] field(Omok omok){
		int[][] reVal = omok.get();
		System.out.println("field");
		System.out.println(reVal);
		return reVal;
	}
	
	/**
	 * 클릭돌놓기 ajax
	 */
	@RequestMapping(value="/panclick",method=RequestMethod.POST)
	@ResponseBody
	public int[][] panclick(HttpServletRequest request){
		String msg = request.getParameter("idx");
		int turn = Integer.parseInt(msg.split("\\$")[1]);
		int idx = Integer.parseInt(msg.split("\\$")[0]);
		String session = msg.split("\\$")[2];
		System.out.println(session);
		int y = idx/15;
		int x = idx%15;
		System.out.println(idx+"==> x="+x+" y="+y);
		Omok omok = getKey(channel, session);
		System.out.println(omok);
		omok.set3(x, y, turn);
		return field(omok);
	}
	
	/**
	 * field() 요청하는 ajax
	 */
	@RequestMapping(value="/field",method=RequestMethod.POST)
	@ResponseBody
	public int[][] field(HttpServletRequest request) {
		String msg = request.getParameter("msg");
		Omok omok = getKey(channel, msg);
		return field(omok);
	}
	
	/**
	 * 돌 놓을 때마다 5개가 됐는지 체크하는 ajax
	 */
	@RequestMapping(value="/endCheck",method=RequestMethod.POST)
	@ResponseBody
	public boolean endCheck(HttpServletRequest request) {
		String msg = request.getParameter("msg");
		Omok omok = getKey(channel, msg);
		if(omok.judgeX()||omok.judgeY()||omok.judgeLeftDown()||omok.judgeRightDown()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * ai가 생각해서 돌놓는 ajax
	 * ai가 선택한 가중치 반환
	 */
	@RequestMapping(value="/AITurn",method=RequestMethod.POST)
	@ResponseBody
	public int[][] AITurn(HttpServletRequest request) {
		String msg = request.getParameter("msg");
		int turn = Integer.parseInt(msg.split(",")[0]);
		String Session = msg.split(",")[1];
		Omok omok = getKey(channel, Session);
		int[][] value = omok.AITurn(turn);
		return value;
	}
	
    public static <K, V> K getKey(Map<K, V> map, V value) {
   	 
        for (K key : map.keySet()) {
            if (value.equals(map.get(key))) {
                return key;
            }
        }
        return null;
    }
}
