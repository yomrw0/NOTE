package com.bit.note.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bit.note.model.dao.NoticeMapper;
import com.bit.note.model.dto.Member;
import com.bit.note.model.dto.Notice;

@Controller
public class NoticeController {

   @Autowired
   NoticeMapper NM;

   @RequestMapping("/noticeList")
   public String noticeList(Model model, HttpSession session) {
      List<Notice> noticeList = NM.noticeList();
      Member member = (Member) session.getAttribute("member");
      String nickName = member.getNickName();
      model.addAttribute("noticeList", noticeList);
      model.addAttribute("nickName", nickName);
      return "noticeList";
   }

   @RequestMapping(value = "/connect", method=RequestMethod.POST)
   @ResponseBody
   public Notice ajax(HttpServletRequest request){
      int noticeNumber = Integer.parseInt(request.getParameter("td"));
      Notice notice = NM.listNotice(noticeNumber);

      return notice;
   }

   @RequestMapping(value = "/insertNotice", method = RequestMethod.GET)
   public String insertNotice(Notice notice, Model model) {
      Date date = new Date();
      java.sql.Date writeDate = new java.sql.Date(date.getTime());

      String title = notice.getTitle();
      String contents = notice.getContents();
      int noticeNumber =  NM.count()+1;
      NM.insertNotice(title, contents, writeDate, noticeNumber);
      return "redirect:/noticeList";
   }

   @RequestMapping(value = "/updateNotice", method = RequestMethod.GET)
   public String updateNotice(Notice notice, int noticeNum, Model model) {
	  String title = notice.getTitle();
	  String contents = notice.getContents();
      NM.updateNotice(title, contents, noticeNum);
      return "redirect:/noticeList";
   }

   @RequestMapping("/deleteNotice")
   public String deleteNotice(int noticeNum, Model model) {

      NM.deleteNotice(noticeNum);

      return "redirect:/noticeList";
   }

}