package com.bit.note.model.dto;

import lombok.Data;

@Data
public class GameRoom {
	private int roomNumber;
	private String roomName;
	private String roomPW;
	private String host;
	private String guest;
	private String status;
}
