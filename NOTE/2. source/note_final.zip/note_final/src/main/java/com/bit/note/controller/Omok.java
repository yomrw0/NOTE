package com.bit.note.controller;

import java.util.Arrays;

public class Omok {
	boolean gameResult;
	boolean returnValue;
	int[][] omokpan;
	int[][] omokpanValue;
	int userTurn;
	int AITurn;

	/**
	 * 게임 시작 생성자
	 */
	public Omok() {
		omokpan = new int[15][15];
		for (int i = 0; i < omokpan.length; i++) {
			Arrays.fill(omokpan[i], 0);
		}

		omokpanValue = new int[15][15];
		for (int i = 0; i < omokpanValue.length; i++) {
			Arrays.fill(omokpanValue[i], 0);
		}

	}

	/**
	 * 현재 상황 확인 메소드
	 */
	public void printField() {
		for (int i = 0; i < omokpan.length; i++) {
			System.out.println(Arrays.toString(omokpan[i]));
		}
	}

	/**
	 * html로 오목 상황 보내는 ajax 메소드
	 */
	public int[][] get() {
		System.out.println("omok.get");
		return omokpan;
	}

	/**
	 * 요청한 자리에 돌이 있는지 확인해서 int 값 리턴 메소드 - 임시
	 */
	public int locationCheck(int x, int y) {
		int ReVal = omokpan[y][x];
		return ReVal;
	}

	/**
	 * 검은 돌 놓는 메소드 - 임시
	 */
	public void set(int x, int y) {
		omokpan[y][x] = 1;
	}

	/**
	 * 흰 돌 놓는 메소드 - 임시
	 */
	public void set2(int x, int y) {
		omokpan[y][x] = 2;
	}

	/**
	 * 클릭 돌 놓는 메소드 - 임시
	 */
	public void set3(int x, int y, int turn) {
		System.out.println("set3");
		System.out.println(userTurn+","+AITurn);
		omokpan[y][x] = turn;
	}

	/**
	 * 승패체크 메소드 - 세로
	 */
	public boolean judgeY() {
		int x;
		int y;
		int count;
		returnValue = false;
		for (x = 0; x < omokpan.length; x++) {//
			count = 1;
			for (y = 0; y < omokpan.length; y++) {
				if (omokpan[y][x] != 0) {// 돌이 있을 때
					if (y - 1 >= 0 && omokpan[y - 1][x] == omokpan[y][x]) { // y가 0이 아니며, 이전 돌과 색이 같을 때
						count += 1;
						if (count == 5) { // 5개가 나란히 있으면 true
							returnValue = true;
						}
						if (count >= 6) {
							if(omokpan[y][x]==-2) { // 백은 6목이상 가능!
								returnValue = true;
							} else if(omokpan[y][x]==-1){ // 흑은 5목만 가능
							returnValue = false;
							}
						}
						if (y == 14) {
							count = 1;
						}
					} else { // 이전 돌과 색이 다르거나 y가 0일 때
						count = 1;
					}
				} else {// 돌이 없을 때
					count = 1;
				}
			}
		}
		return returnValue;
	}

	/**
	 * 승패체크 메소드 - 가로
	 */
	public boolean judgeX() {
		int x;
		int y;
		int count;
		returnValue = false;
		for (y = 0; y < omokpan.length; y++) {//
			count = 1;
			for (x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] != 0) {// 돌이 있을 때
					if (x - 1 >= 0 && omokpan[y][x - 1] == omokpan[y][x]) { // x가 0이 아니며, 이전 돌과 색이 같을 때
						count += 1;
						if (count == 5) { // 5개가 나란히 있으면 true
							returnValue = true;
						}
						if (count >= 6) {
							if(omokpan[y][x]==-2) { // 백은 6목이상 가능!
								returnValue = true;
							} else if(omokpan[y][x]==-1){ // 흑은 5목만 가능
							returnValue = false;
							}
						}
						if (x == 14) {
							count = 1;
						}
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
				} else {// 돌이 없을 때
					count = 1;
				}
			}
		}
		return returnValue;
	}

	/**
	 * 승패체크 메소드 - 왼쪽 대각선
	 */
	public boolean judgeLeftDown() {
		int x;
		int y;
		int count = 1;
		returnValue = false;
		for (int spin = 0; spin < 29; spin++) {
			for (y = 0; y < omokpan.length; y++) {
				x = spin - y;
				if (x >= 0 && x < omokpan.length) {// 15x15 내일 때
					if (y - 1 >= 0 && x + 1 < omokpan.length) {// x나 y가 0이 아닐 때
						if (omokpan[y][x] != 0) { // 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x + 1]) {
								count += 1;
								if (count == 5) {
									returnValue = true;
								}
								if (count >= 6) {
									if(omokpan[y][x]==-2) { // 백은 6목이상 가능!
										returnValue = true;
									} else if(omokpan[y][x]==-1){ // 흑은 5목만 가능
									returnValue = false;
									}
								}
								if (spin <= 14 && x == 0) {
									count = 1;
								} else if (spin > 14 && y == 14) {
									count = 1;
								}
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
						} else {// 돌이 없을 때
							count = 1;
						}
					}
				}
			}
		}
		return returnValue;
	}

	/**
	 * 승패체크 메소드 - 오른쪽 대각선
	 */
	public boolean judgeRightDown() {
		int x;
		int y;
		int SPIN;
		int count = 1;
		returnValue = false;
		for (SPIN = 0; SPIN < 15; SPIN++) {
			y = 0;
			for (x = 14 - SPIN; x <= 14; x++) {
				if (y >= 0 && y <= SPIN) { // 15x15 내일 때
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] != 0) { // 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) {
								count += 1;
								if (count == 5) {
									returnValue = true;
								}
								if (count >= 6) {
									if(omokpan[y][x]==-2) { // 백은 6목이상 가능!
										returnValue = true;
									} else if(omokpan[y][x]==-1){ // 흑은 5목만 가능
									returnValue = false;
									}
								}
								if (x == 14) {
									count = 1;
								}
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
						} else { // 돌이 없을 때
							count = 1;
						}
					}
				}
				y++;
			}
		}

		for (SPIN = 1; SPIN < 15; SPIN++) {
			count = 1;
			y = SPIN;
			for (x = 0; x <= 14 - SPIN; x++) {
				if (y >= 1 && y <= 14) {
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] != 0) { // 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) {
								count += 1;
								if (count == 5) {
									returnValue = true;
								}
								if (count >= 6) {
									if(omokpan[y][x]==-2) { // 백은 6목이상 가능!
										returnValue = true;
									} else if(omokpan[y][x]==-1){ // 흑은 5목만 가능
									returnValue = false;
									}
								}
								if (y == 14) {
									count = 1;
								}
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
						} else { // 돌이 없을 때
							count = 1;
						}
					}
				}
				y++;
			}
		}

		return returnValue;
	}

	/**
	 * ai가 분석하는 메소드 --> 최고점수
	 */
	public int[][] AITurn(int turn) {
		System.out.println("turn=="+turn);
		AITurn = turn;
		System.out.println("AITurn=="+AITurn);
		AIConnectsValues();
		printValue();
		int max = 0;
		int maxy = 0;
		int maxx = 0;
		for (int y = 0; y < omokpan.length; y++) {
			for (int x = 0; x < omokpan.length; x++) {
				if (omokpanValue[y][x] > max) {
					max = omokpanValue[y][x];
					maxx = x;
					maxy = y;
				}
				if (omokpanValue[y][x] == max) { // 여러개면 중심에 가까운 값으로
					if (maxx <= 7 && maxy <= 7 && x >= maxx && y >= maxy) {
						maxx = x;
						maxy = y;
					}
					if (maxx >= 7 && maxy <= 7 && x <= maxx && y >= maxy) {
						maxx = x;
						maxy = y;
					}
					if (maxx <= 7 && maxy >= 7 && x >= maxx && y <= maxy) {
						maxx = x;
						maxy = y;
					}
					if (maxx >= 7 && maxy >= 7 && x <= maxx && y <= maxy) {
						maxx = x;
						maxy = y;
					}
				}
			}
		}
		set3(maxx, maxy, AITurn);
		return omokpan;
	}

	/**
	 * 돌 주변에 점수 넣는 메소드
	 */
	public void LocationValueCheck() {
		for (int y = 0; y < omokpan.length; y++) {
			for (int x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] == userTurn || omokpan[y][x] == AITurn) {
					if (x <= 13) {
						if (omokpanValue[y][x + 1] == 0)
							omokpanValue[y][x + 1] += 30;
						if (y <= 13) {
							if (omokpanValue[y + 1][x + 1] == 0)
								omokpanValue[y + 1][x + 1] += 30;
						}
					}
					if (y <= 13) {
						if (omokpanValue[y + 1][x] == 0)
							omokpanValue[y + 1][x] += 30;
					}

					if (y >= 1) {
						if (omokpanValue[y - 1][x] == 0)
							omokpanValue[y - 1][x] += 30;
						if (x <= 13) {
							if (omokpanValue[y - 1][x + 1] == 0)
								omokpanValue[y - 1][x + 1] += 30;
						}
						if (x >= 1) {
							if (omokpanValue[y - 1][x - 1] == 0)
								omokpanValue[y - 1][x - 1] += 30;
						}
					}
					if (x >= 1) {
						if (omokpanValue[y][x - 1] == 0)
							omokpanValue[y][x - 1] += 30;
						if (y <= 13) {
							if (omokpanValue[y + 1][x - 1] == 0)
								omokpanValue[y + 1][x - 1] += 30;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 돌 주변 추가 점수
	 */
	public void AIExtraValue() {
		for (int y = 0; y < omokpan.length; y++) {
			for (int x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] == AITurn) {
					if (x <= 13) {
						if (omokpanValue[y][x + 1] >= 0)
							omokpanValue[y][x + 1] += 5;
						if (y <= 13) {
							if (omokpanValue[y + 1][x + 1] >= 0)
								omokpanValue[y + 1][x + 1] += 5;
						}
					}
					if (y <= 13) {
						if (omokpanValue[y + 1][x] >= 0)
							omokpanValue[y + 1][x] += 5;
					}

					if (y >= 1) {
						if (omokpanValue[y - 1][x] >= 0)
							omokpanValue[y - 1][x] += 5;
						if (x <= 13) {
							if (omokpanValue[y - 1][x + 1] >= 0)
								omokpanValue[y - 1][x + 1] += 5;
						}
						if (x >= 1) {
							if (omokpanValue[y - 1][x - 1] >= 0)
								omokpanValue[y - 1][x - 1] += 5;
						}
					}
					if (x >= 1) {
						if (omokpanValue[y][x - 1] >= 0)
							omokpanValue[y][x - 1] += 5;
						if (y <= 13) {
							if (omokpanValue[y + 1][x - 1] >= 0)
								omokpanValue[y + 1][x - 1] += 5;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 가중치 증가
	 */
	public void AIConnectsValues() {
		reset(); // 매 턴 초기화
		minusSet();
		LocationValueCheck(); // 위치지정, 초기값
		AIExtraValue(); // 뽀나스점수
		AIConnectAll(); // 필드분석, 가중치 추가
		AIDefenceAll(); // 사용자 돌 검색해서 방어 가중치 추가
	}

	public void reset() {
		for (int i = 0; i < omokpanValue.length; i++) {
			Arrays.fill(omokpanValue[i], 0);
		}
	}

	public void AIConnectAll() {
		AIConnectX(); // →
		AIConnectXReverse(); // ←
		AIConnectY(); // ↓
		AIConnectYReverse(); // ↑
		AIConnectLeftDown(); // ↙
		AIConnectLeftDownReverse(); // ↗
		AIConnectRightDown(); // ↘
		AIConnectRightDownReverse(); // ↖
	}

	public void AIDefenceAll() {
		AIDefenceX(); // →
		AIDefenceXReverse(); // ←
		AIDefenceY(); // ↓
		AIDefenceYReverse(); // ↑
		AIDefenceLeftDown(); // ↙
		AIDefenceLeftDownReverse(); // ↗
		AIDefenceRightDown(); // ↘
		AIDefenceRightDownReverse(); // ↖
	}

	/**
	 * AI 돌 잇기 X
	 */
	public void AIConnectX() {
		int x;
		int y;
		int count;
		for (y = 0; y < omokpan.length; y++) {//
			count = 1;
			for (x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					if (x != 0 && omokpan[y][x - 1] == omokpan[y][x]) { // x가 0이 아니며, 이전 돌도 흰 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
					if (x == 14) {
						count = 1;
					}
				} else if (omokpan[y][x] == userTurn) {// 다른 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
					System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectX");
					}
					if (count == 4) {
						if(AITurn==-1&&x+1<=14&&omokpan[y][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
						}else if (x <= 14 && omokpan[y][x] == 0) {
							omokpanValue[y][x] += 5000;
						}					
					}
					if (count == 3) {
						if (x + 2 <= 14) { // 3 0 1
							if (omokpan[y][x + 1] == AITurn && omokpan[y][x + 2] != AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}else if (x + 1 <= 14){
							if (omokpan[y][x + 1] == AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}
						if (x - count - 1 >= 0) {
							if (omokpan[y][x - count - 1] == 0) { // 양옆없을 때
								omokpanValue[y][x] += 1050;
							}
						}
					}
					if (count == 2) { // 2 연쇄 이상일 경우
						if (x - count + 4 <= 14) { // 연결 안 되면 가중치 X
							if (x <= 14 && omokpan[y][x] == 0) { // 연쇄마다 가중치 증가
								omokpanValue[y][x] += count * 50;
								if (x - count - 1 >= 0) {
									if (omokpan[y][x - count - 1] == 0) { // 양옆없을 때
										omokpanValue[y][x] += 35;
									}
								}
								if (x + 1 <= 14 && x - 3 >= 0) {
									if (omokpan[y][x + 1] == AITurn && omokpan[y][x - 3] == 0) { // 0201
										omokpanValue[y][x] += 500;
									}
									if (x + 2 <= 14 && omokpan[y][x + 1] == AITurn && omokpan[y][x + 2] == 0) { // 2010
										omokpanValue[y][x] += 500;
									}
								}
								if (x + 2 <= 14 && omokpan[y][x + 1] == AITurn && omokpan[y][x + 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
						} // 연결 안 되면 가중치 X end
					}
					if (x - 2 >= 0 && x + 2 <= 14 && count == 1) { // 1 0 1 일 때 (정방향, 리버스 중 하나만)
						if (omokpan[y][x - 1] == AITurn && omokpan[y][x + 1] == AITurn && omokpan[y][x - 2] == 0
								&& omokpan[y][x + 2] == 0) {
							omokpanValue[y][x] += 185;
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 X Reverse
	 */
	public void AIConnectXReverse() {
		int x;
		int y;
		int count;
		for (y = 0; y < omokpan.length; y++) {//
			count = 1;
			for (x = omokpan.length - 1; x >= 0; x--) {
				if (omokpan[y][x] == AITurn && x != 14) {// x가 14가 아니며, 흰 돌이 있을 때
					if (omokpan[y][x + 1] == omokpan[y][x]) { // 이전 돌도 흰 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
					if (x == 0) {
						count = 1;
					}
				} else if (omokpan[y][x] == userTurn) {// 다른 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
					System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectXReverse");
					}
					if (count == 4) {
						if(AITurn==-1&&x-1>=0&&omokpan[y][x-1]==AITurn) { // 흑이고 6목이상이면 점수 X
						} else if (x >= 0 && omokpan[y][x] == 0) {
							omokpanValue[y][x] += 5000;
						}
					}
					if (count == 3) {
						if (x - 2 >= 0) { // 3 0 1
							if (omokpan[y][x - 1] == AITurn && omokpan[y][x - 2] != AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}else if (x - 1 >= 0){
							if (omokpan[y][x - 1] == AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}
						if (x + count + 1 <= 14) {
							if (omokpan[y][x + count + 1] == 0) { // 양옆없을 때
								omokpanValue[y][x] += 1050;
							}
						}
					}
					if (count == 2) { // 2 연쇄 이상일 경우
						if (x + count - 4 >= 0) { // 연결 안 되면 가중치 X
							if (x >= 0 && omokpan[y][x] == 0) { // 연쇄마다 가중치 증가
								omokpanValue[y][x] += count * 50;
								if (x + count + 1 <= 14) {
									if (omokpan[y][x + count + 1] == 0) { // 양옆없을 때
										omokpanValue[y][x] += 35;
									}
								}
								if (x - 1 >= 0 && x + 3 <= 14) {
									if (omokpan[y][x - 1] == AITurn && omokpan[y][x + 3] == 0) { // 1020
										omokpanValue[y][x] += 500;
									}
									if (x - 2 >= 0 && omokpan[y][x - 1] == AITurn && omokpan[y][x - 2] == 0) { // 0102
										omokpanValue[y][x] += 500;
									}
								}
								if (x - 2 >= 0 && omokpan[y][x - 1] == AITurn && omokpan[y][x - 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
						} // 연결 안 되면 가중치 X end
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 Y
	 */
	public void AIConnectY() {
		int x;
		int y;
		int count;
		returnValue = false;
		for (x = 0; x < omokpan.length; x++) {//
			count = 1;
			for (y = 0; y < omokpan.length; y++) {
				if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					if (y != 0 && omokpan[y - 1][x] == omokpan[y][x]) { // y가 0이 아니며, 이전 돌도 흰 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 y가 0일 때
						count = 1;
					}
					if (y == 14) {
						count = 0;
					}
				} else if (omokpan[y][x] == userTurn) {// 다른 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
					System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectY");
					}
					if (count == 4) {
						if(AITurn==-1&&y+1<=14&&omokpan[y+1][x]==AITurn) { // 흑이고 6목이상이면 점수 X
						}else if (y <= 14 && omokpan[y][x] == 0) {
							omokpanValue[y][x] += 5000;
						}
					}
					if (count == 3) {
						if (y + 2 <= 14) { // 3 0 1
							if (omokpan[y + 1][x] == AITurn && omokpan[y+2][x] != AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}else if (y + 1 <= 14){
							if (omokpan[y + 1][x] == AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}
						if (y - count - 1 >= 0) {
							if (omokpan[y - count - 1][x] == 0) {// 양옆없을 때
								omokpanValue[y][x] += 1050;
							}
						}
					}
					if (count == 2) { // 2 연쇄 이상일 경우
						if (y - count + 4 <= 14) { // 연결 안 되면 가중치 X
							if (y <= 14 && omokpan[y][x] == 0) {
								omokpanValue[y][x] += count * 50;
								if (y - count - 1 >= 0) {
									if (omokpan[y - count - 1][x] == 0) {// 양옆없을 때
										omokpanValue[y][x] += 35;
									}
								}
								if (y + 1 <= 14 && y - 3 >= 0) {
									if (omokpan[y + 1][x] == AITurn && omokpan[y - 3][x] == 0) { // 0201
										omokpanValue[y][x] += 500;
									}
									if (y + 2 <= 14 && omokpan[y + 1][x] == AITurn && omokpan[y + 2][x] == 0) { // 2010
										omokpanValue[y][x] += 500;
									}
								}
								if (y + 2 <= 14 && omokpan[y + 1][x] == AITurn && omokpan[y + 2][x] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
						} // 연결 안 되면 가중치 X end
					}
					if (y - 2 >= 0 && y + 2 <= 14 && count == 1) { // 1 0 1 일 때 (정방향, 리버스 중 하나만)
						if (omokpan[y - 1][x] == AITurn && omokpan[y + 1][x] == AITurn && omokpan[y - 2][x] == 0
								&& omokpan[y + 2][x] == 0) {
							omokpanValue[y][x] += 185;
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 Y Reverse
	 */
	public void AIConnectYReverse() {
		int x;
		int y;
		int count;
		returnValue = false;
		for (x = 0; x < omokpan.length; x++) {//
			count = 1;
			for (y = omokpan.length - 1; y >= 0; y--) {
				if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					if (y+1<=14 && omokpan[y + 1][x] == omokpan[y][x]) { // y가 0이 아니며, 이전 돌도 흰 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 y가 0일 때
						count = 1;
					}
					if (y == 0) {
						count = 1;
					}
				} else if (omokpan[y][x] == userTurn) {// 다른 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
					System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectYReverse");
					}
					if (count == 4) {
						if(AITurn==-1&&y-1>=0&&omokpan[y-1][x]==AITurn) { // 흑이고 6목이상이면 점수 X
						} else if (y >= 0 && omokpan[y][x] == 0) {
							omokpanValue[y][x] += 5000;
						}
					}
					if (count == 3) {
						if (y - 2 >= 0) { // 3 0 1
							if (omokpan[y - 1][x] == AITurn && omokpan[y-2][x] != AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}else if (y - 1 >= 0){
							if (omokpan[y - 1][x] == AITurn) {
								omokpanValue[y][x] += 5000;
							}
						}
						if (y + count + 1 <= 14) {
							if (omokpan[y + count + 1][x] == 0) {// 양옆없을 때
								omokpanValue[y][x] += 1050;
							}
						}
					}
					if (count == 2) { // 2 연쇄 이상일 경우
						if (y + count - 4 >= 0) { // 연결 안 되면 가중치 X
							if (y >= 0 && omokpan[y][x] == 0) {
								omokpanValue[y][x] += count * 50;
								if (y + count + 1 <= 14) {
									if (omokpan[y + count + 1][x] == 0) {// 양옆없을 때
										omokpanValue[y][x] += 35;
									}
								}
								if (y - 1 >= 0 && y + 3 <= 14) {
									if (omokpan[y - 1][x] == AITurn && omokpan[y + 3][x] == 0) { // 1020
										omokpanValue[y][x] += 500;
									}
									if (y - 2 >= 0 && omokpan[y - 1][x] == AITurn && omokpan[y - 2][x] == 0) { // 0102
										omokpanValue[y][x] += 500;
									}
								}
								if (y - 2 >= 0 && omokpan[y - 1][x] == AITurn && omokpan[y - 2][x] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
						} // 연결 안 되면 가중치 X end
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 왼쪽 대각선
	 */
	public void AIConnectLeftDown() {
		int x;
		int y;
		int count = 1;
		for (int spin = 0; spin < 29; spin++) {
			for (y = 0; y < omokpan.length; y++) {
				x = spin - y;
				if (x >= 0 && x < omokpan.length) {// 15x15 내일 때
					if (y - 1 >= 0 && x + 1 < omokpan.length) {// x나 y가 0이 아닐 때
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x + 1]) {// 이전 돌도 흰 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (spin <= 14 && x == 0) {
								count = 1;
							} else if (spin > 14 && y == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) {// 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectLeftDown");
								}
							if (count == 4) {
								if(AITurn==-1&&y+1<=14&&x-1>=0&&omokpan[y+1][x-1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else if (y <= 14 && x >= 0 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
								if (y + 2 <= 14 && x - 2 >= 0) { // 3 0 1
									if (omokpan[y + 1][x - 1] == AITurn && omokpan[y+2][x-2] != AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}else if (y + 1 <= 14 && x - 1 >= 0){
									if (omokpan[y + 1][x - 1] == AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}
								if (y - count - 1 >= 0 && x + count + 1 <= 14) {
									if (omokpan[y - count - 1][x + count + 1] == 0) {// 양옆없을 때
										omokpanValue[y][x] += 1050;
									}
								}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (x + count - 4 >= 0) { // 어짜피 5개 못 두면 가중치 X
									if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
										omokpanValue[y][x] += count * 50;
										if (y - count - 1 >= 0 && x + count + 1 <= 14) {
											if (omokpan[y - count - 1][x + count + 1] == 0) {// 양옆없을 때
												omokpanValue[y][x] += 35;
											}
										}
										if (y + 1 <= 14 && y - 3 >= 0 && x - 1 >= 0 && x + 3 <= 14) {
											if (omokpan[y + 1][x - 1] == AITurn && omokpan[y - 3][x + 3] == 0) { // 0201
												omokpanValue[y][x] += 500;
											}
											if (y + 2 <= 14 && x - 2 >= 0 && omokpan[y + 1][x - 1] == AITurn
													&& omokpan[y + 2][x - 2] == 0) { // 2010
												omokpanValue[y][x] += 500;
											}
										}
										if (y + 2 <= 14 && x - 2 >= 0 && omokpan[y + 1][x - 1] == AITurn
												&& omokpan[y + 2][x - 2] == AITurn) { // 202
											omokpanValue[y][x] += 5000;
										}
									}
								}
							}
							if (y - 2 >= 0 && y + 2 <= 14 && x - 2 >= 0 && x + 2 <= 14 && count == 1) { // 1 0 1 일 때
																										// (정방향, 리버스 중
																										// 하나만)
								if (omokpan[y - 1][x + 1] == AITurn && omokpan[y + 1][x - 1] == AITurn
										&& omokpan[y - 2][x + 2] == 0 && omokpan[y + 2][x - 2] == 0) {
									omokpanValue[y][x] += 185;
								}
							}
							count = 1;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 왼쪽 대각선 Reverse
	 */
	public void AIConnectLeftDownReverse() {
		int x;
		int y;
		int count = 1;
		for (int spin = 0; spin < 29; spin++) {
			y = 15;
			for (x = omokpan.length - 1 - spin; x <= 14; x++) {
				y--;
				if (x >= 0 && x < omokpan.length && y >= 0 && y < omokpan.length) {// 15x15 내일 때
					if (y + 1 <= 14 && x - 1 >= 0) {
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x - 1]) { // 이전 돌도 흰 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (spin <= 14 && x == 14) {
								count = 1;
							} else if (spin > 14 && y == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) { // 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때 (돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectLeftDownReverse");
								}
							if (count == 4) {
								if(AITurn==-1&&y-1>=0&&x+1<=14&&omokpan[y-1][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else {
								omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
							if (y - 2 >= 0 && x + 2 <= 14) { // 3 0 1
								if (omokpan[y - 1][x + 1] == AITurn && omokpan[y-2][x+2] != AITurn) {
									omokpanValue[y][x] += 5000;
								}
							}else if (y - 1 >= 0 && x + 1 <= 14){
								if (omokpan[y - 1][x + 1] == AITurn) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (y + count + 1 <= 14 && x - count - 1 >= 0) {
								if (omokpan[y + count + 1][x - count - 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 1050;
								}
							}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (x - count + 4 <= 14) {// 어짜피 5개 못 두면 가중치 X
									omokpanValue[y][x] += count * 50;
									if (y + count + 1 <= 14 && x - count - 1 >= 0) {
										if (omokpan[y + count + 1][x - count - 1] == 0) { // 양옆없을 때
											omokpanValue[y][x] += 35;
										}
									}
									if (y - 1 >= 0 && y + 3 <= 14 && x + 1 <= 14 && x - 3 >= 0) {
										if (omokpan[y - 1][x + 1] == AITurn && omokpan[y + 3][x - 3] == 0) { // 1020
											omokpanValue[y][x] += 500;
										}
										if (x + 2 <= 14 && y - 2 >= 0 && omokpan[y - 1][x + 1] == AITurn
												&& omokpan[y - 2][x + 2] == 0) { // 0102
											omokpanValue[y][x] += 500;
										}
									}
									if (y - 2 >= 0 && x + 2 <= 14 && omokpan[y - 1][x + 1] == AITurn
											&& omokpan[y - 2][x + 2] == AITurn) { // 202
										omokpanValue[y][x] += 5000;
									}
								}
							}
							count = 1;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 돌 잇기 오른쪽 대각선
	 */
	public void AIConnectRightDown() {
		int x;
		int y;
		int SPIN;
		int count = 1;
		for (SPIN = 0; SPIN < 15; SPIN++) {
			y = 0;
			for (x = 14 - SPIN; x <= 14; x++) {
				if (y >= 0 && y <= SPIN) { // 15x15 내일 때
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) { // 이전 돌도 흰 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (x == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) { // 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectRightDown");
								}
							if (count == 4) {
								if(AITurn==-1&&y+1<=14&&x+1<=14&&omokpan[y+1][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
								if (y + 2 <= 14 && x + 2 <= 14) { // 3 0 1
									if (omokpan[y + 1][x + 1] == AITurn && omokpan[y+2][x+2] != AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}else if (y + 1 <= 14 && x + 1 <= 14){
									if (omokpan[y + 1][x + 1] == AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}
								if (y - count - 1 >= 0 && x - count - 1 >= 0
										&& omokpan[y - count - 1][x - count - 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 1050;
								}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (y - count - 1 >= 0 && x - count - 1 >= 0
										&& omokpan[y - count - 1][x - count - 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 35;
								}
								if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += count * 50;
								}
								if (y + 1 <= 14 && y - 3 >= 0 && x - 3 >= 0 && x + 1 <= 14) {
									if (omokpan[y + 1][x + 1] == AITurn && omokpan[y - 3][x - 3] == 0) { // 0201
										omokpanValue[y][x] += 500;
									}
									if (y + 2 <= 14 && x + 2 <= 14 && omokpan[y + 1][x + 1] == AITurn
											&& omokpan[y + 2][x + 2] == 0) { // 2010
										omokpanValue[y][x] += 500;
									}
								}
								if (y + 2 <= 14 && x + 2 <= 14 && omokpan[y + 1][x + 1] == AITurn
										&& omokpan[y + 2][x + 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
							if (y - 2 >= 0 && y + 2 <= 14 && x - 2 >= 0 && x + 2 <= 14 && count == 1) { // 1 0 1 일 때
								// (정방향, 리버스 중
								// 하나만)
								if (omokpan[y - 1][x - 1] == AITurn && omokpan[y + 1][x + 1] == AITurn
										&& omokpan[y - 2][x - 2] == 0 && omokpan[y + 2][x + 2] == 0) {
									omokpanValue[y][x] += 185;
								}
							}
							count = 1;
						}
					}
				}
				y++;
			}
		}

		for (SPIN = 1; SPIN < 15; SPIN++) {
			count = 1;
			y = SPIN;
			for (x = 0; x <= 14 - SPIN; x++) {
				if (y >= 1 && y <= 14) {
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) {
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (y == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) { // 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectRightDown");
								}
							if (count == 4) {
								if(AITurn==-1&&y+1<=14&&x+1<=14&&omokpan[y+1][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
								if (y + 2 <= 14 && x + 2 <= 14) { // 3 0 1
									if (omokpan[y + 1][x + 1] == AITurn && omokpan[y+2][x+2] != AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}else if (y + 1 <= 14 && x + 1 <= 14){
									if (omokpan[y + 1][x + 1] == AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}
								if (y - count - 1 >= 0 && x - count - 1 >= 0
										&& omokpan[y - count - 1][x - count - 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 1050;
								}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (y - count - 1 >= 0 && x - count - 1 >= 0
										&& omokpan[y - count - 1][x - count - 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 35;
								}
								if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += count * 50;
								}
								if (y + 1 <= 14 && y - 3 >= 0 && x - 3 >= 0 && x + 1 <= 14) {
									if (omokpan[y + 1][x + 1] == AITurn && omokpan[y - 3][x - 3] == 0) { // 0201
										omokpanValue[y][x] += 500;
									}
									if (y + 2 <= 14 && x + 2 <= 14 && omokpan[y + 1][x + 1] == AITurn
											&& omokpan[y + 2][x + 2] == 0) { // 2010
										omokpanValue[y][x] += 500;
									}
								}
								if (y + 2 <= 14 && x + 2 <= 14 && omokpan[y + 1][x + 1] == AITurn
										&& omokpan[y + 2][x + 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
							if (y - 2 >= 0 && y + 2 <= 14 && x - 2 >= 0 && x + 2 <= 14 && count == 1) { // 1 0 1 일 때
								// (정방향, 리버스 중
								// 하나만)
								if (omokpan[y - 1][x - 1] == AITurn && omokpan[y + 1][x + 1] == AITurn
										&& omokpan[y - 2][x - 2] == 0 && omokpan[y + 2][x + 2] == 0) {
									omokpanValue[y][x] += 185;
								}
							}
							count = 1;
						}
					}
				}
			}
			y++;
		}
	}

	/**
	 * AI 돌 잇기 오른쪽 대각선 Reverse
	 */
	public void AIConnectRightDownReverse() {
		int x;
		int y;
		int SPIN;
		int count = 1;
		for (SPIN = 0; SPIN < 15; SPIN++) {
			x = SPIN;
			for (y = 14; y >= 0; y--) {
				if (x >= 0) { // 15x15 내일 때
					if (y + 1 <= 14 && x + 1 <= 14) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x + 1]) { // 이전 돌도 흰 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (x == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) { // 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectRightDownReverse");
								}
							if (count == 4) {
								if(AITurn==-1&&y-1>=0&&x-1>=0&&omokpan[y+1][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else if (y >= 0 && x >= 0 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
								if (y - 2 >= 0 && x - 2 >= 0) { // 3 0 1
									if (omokpan[y - 1][x - 1] == AITurn && omokpan[y-2][x-2] != AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}else if (y - 1 >= 0 && x - 1 >= 0){
									if (omokpan[y - 1][x - 1] == AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}
								if (y + count + 1 <= 14 && x + count + 1 <= 14
										&& omokpan[y + count + 1][x - count + 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 1050;
								}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (y + count + 1 <= 14 && x + count + 1 <= 14
										&& omokpan[y + count + 1][x - count + 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 35;
								}
								if (y >= 0 && x <= 14 && x >= 0 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += count * 50;
								}
								if (y + 3 <= 14 && y - 1 >= 0 && x - 1 >= 0 && x + 3 <= 14) {
									if (omokpan[y - 1][x - 1] == AITurn && omokpan[y + 3][x + 3] == 0) { // 1020
										omokpanValue[y][x] += 500;
									}
									if (y - 2 >= 0 && x - 2 >= 0 && omokpan[y - 1][x - 1] == AITurn
											&& omokpan[y - 2][x - 2] == 0) { // 0102
										omokpanValue[y][x] += 500;
									}
								}
								if (y - 2 >= 0 && x - 2 >= 0 && omokpan[y - 1][x - 1] == AITurn
										&& omokpan[y - 2][x - 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
							count = 1;
						}
					}
				}
				x--;
			}
		}

		for (SPIN = 1; SPIN < 15; SPIN++) {
			y = 14 - SPIN;
			for (x = 14; x >= 0; x--) {
				if (y >= 0) { // 15x15 내일 때
					if (y + 1 <= 14 && x + 1 <= 14) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x + 1]) { // 이전 돌도 흰 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (y == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == userTurn) { // 다른 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIConnectRightDownReverse");
								}
							if (count == 4) {
								if(AITurn==-1&&y-1>=0&&x-1>=0&&omokpan[y+1][x+1]==AITurn) { // 흑이고 6목이상이면 점수 X
								} else if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += 5000;
								}
							}
							if (count == 3) {
								if (y - 2 >= 0 && x - 2 >= 0) { // 3 0 1
									if (omokpan[y - 1][x - 1] == AITurn && omokpan[y-2][x-2] != AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}else if (y - 1 >= 0 && x - 1 >= 0){
									if (omokpan[y - 1][x - 1] == AITurn) {
										omokpanValue[y][x] += 5000;
									}
								}
								if (y + count + 1 <= 14 && x + count + 1 <= 14
										&& omokpan[y + count + 1][x - count + 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 1050;
								}
							}
							if (count == 2) { // 2 연쇄 이상일 경우
								if (y + count + 1 <= 14 && x + count + 1 <= 14
										&& omokpan[y + count + 1][x - count + 1] == 0) { // 양옆없을 때
									omokpanValue[y][x] += 35;
								}
								if (y >= 0 && x <= 14 && x >= 0 && omokpan[y][x] == 0) {
									omokpanValue[y][x] += count * 50;
								}
								if (y + 3 <= 14 && y - 1 >= 0 && x - 1 >= 0 && x + 3 <= 14) {
									if (omokpan[y - 1][x - 1] == AITurn && omokpan[y + 3][x + 3] == 0) { // 1020
										omokpanValue[y][x] += 500;
									}
									if (y - 2 >= 0 && x - 2 >= 0 && omokpan[y - 1][x - 1] == AITurn
											&& omokpan[y - 2][x - 2] == 0) { // 0102
										omokpanValue[y][x] += 500;
									}
								}
								if (y - 2 >= 0 && x - 2 >= 0 && omokpan[y - 1][x - 1] == AITurn
										&& omokpan[y - 2][x - 2] == AITurn) { // 202
									omokpanValue[y][x] += 5000;
								}
							}
							count = 1;
						}
					}
				}
				y--;
			}
		}

	}

	/**
	 * AI 디펜스 X
	 */
	public void AIDefenceX() {
		int x;
		int y;
		int count;
		for (y = 0; y < omokpan.length; y++) {//
			count = 1;
			for (x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] == userTurn) {// 검은 돌이 있을 때
					if (x != 0 && omokpan[y][x - 1] == omokpan[y][x]) { // x가 0이 아니며, 이전 돌도 검은 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
					if (x == 14) { // 끝에가면 초기화
						count = 1;
					}
				} else if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
						System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceX");
						}
					if (count == 4) {
						if (x <= 14 && omokpan[y][x] == 0) {
							if(x+1<=14&&AITurn==-2&&omokpan[y][x+1]==userTurn) { // 백일 때 6목이면 안 막음
							} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
							omokpanValue[y][x] += 3000;
							}
						}
					}
					if (count == 3) { // 3 연쇄일 경우
						if (x - 4 >= 0 && x <= 14) { // 0 3 0
							if (omokpan[y][x] == 0 && omokpan[y][x - 4] == 0) {
								omokpanValue[y][x - 4] += 1000;
							}
						}
						if (x + 1 <= 14) { // 3 0 1 0
							if (x + 2 <= 14) {
								if (omokpan[y][x] == 0 && omokpan[y][x + 1] == userTurn
										&& omokpan[y][x + 2] != userTurn) {
									omokpanValue[y][x] += 3000;
								}
							} else {
								if (omokpan[y][x] == 0 && omokpan[y][x + 1] == userTurn) {
									omokpanValue[y][x] += 3000;
								}
							}
						}
					}
					if (count == 2) {
						if (x + 2 <= 14) { // 2 0 2
							if (omokpan[y][x + 1] == userTurn && omokpan[y][x + 2] == userTurn) {
								omokpanValue[y][x] += 3000;
							}
						}
						if (x + 1 <= 14) { // 0 2 0 1
							if (omokpan[y][x] == 0 && omokpan[y][x + 1] == userTurn) {
								if(x-count-1>=0 && omokpan[y][x-count-1]==0)
								omokpanValue[y][x] += 1000;
							}
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 디펜스 X Reverse
	 */
	public void AIDefenceXReverse() {
		int x;
		int y;
		int count;
		for (y = 0; y < omokpan.length; y++) {//
			count = 1;
			for (x = omokpan.length - 1; x >= 0; x--) {
				if (omokpan[y][x] == userTurn && x != 14) {// x가 14가 아니며, 검은 돌이 있을 때
					if (omokpan[y][x + 1] == omokpan[y][x]) { // 이전 돌도 검은 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
					if (x == 0) { // 끝에가면 초기화
						count = 1;
					}
				} else if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
						System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceXReverse");
						}
					if (count == 4) {
						if (x >= 0 && omokpan[y][x] == 0) {
							if(x-1>=0&&AITurn==-2&&omokpan[y][x-1]==userTurn) { // 백일 때 6목이면 안 막음
							} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
							omokpanValue[y][x] += 3000;
							}
						}
					}
					if (count == 3) { // 3 연쇄일 경우
						if (x + 4 <= 14 && x >= 0) { // 0 3 0
							if (omokpan[y][x] == 0 && omokpan[y][x + 4] == 0) {
								omokpanValue[y][x + 4] += 1000;
							}
						}
						if (x - 1 >= 0) { // 3 0 1 0
							if (x - 2 >= 0) {
								if (omokpan[y][x] == 0 && omokpan[y][x - 1] == userTurn
										&& omokpan[y][x - 2] != userTurn) {
									omokpanValue[y][x] += 3000;
								}
							} else {
								if (omokpan[y][x] == 0 && omokpan[y][x - 1] == userTurn) {
									omokpanValue[y][x] += 3000;
								}
							}
						}
					}
					if (count == 2) {
						if (x - 2 >= 0) { // 2 0 2
							if (omokpan[y][x - 1] == userTurn && omokpan[y][x - 2] == userTurn) {
								omokpanValue[y][x] += 3000;
							}
						}
						if (x - 1 >= 0) { // 0 2 0 1
							if (omokpan[y][x] == 0 && omokpan[y][x - 1] == userTurn) {
								if(x+count+1<=14 && omokpan[y][x+count+1]==0)
								omokpanValue[y][x] += 1000;
							}
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 디펜스 Y
	 */
	public void AIDefenceY() {
		int x;
		int y;
		int count;
		returnValue = false;
		for (x = 0; x < omokpan.length; x++) {//
			count = 1;
			for (y = 0; y < omokpan.length; y++) {
				if (omokpan[y][x] == userTurn) {// 검은 돌이 있을 때
					if (y != 0 && omokpan[y - 1][x] == omokpan[y][x]) { // y가 0이 아니며, 이전 돌도 흰 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 y가 0일 때
						count = 1;
					}
					if (y == 14) { // 끝에가면 초기화
						count = 0;
					}
				} else if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
						System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceY");
						}
					if (count == 4) {
						if (y <= 14 && omokpan[y][x] == 0) {
							if(y+1<=14&&AITurn==-2&&omokpan[y+1][x]==userTurn) { // 백일 때 6목이면 안 막음
							} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
							omokpanValue[y][x] += 3000;
							}
						}
					}
					if (count == 3) { // 3 연쇄일 경우
						if (y - 4 >= 0 && y <= 14) { // 0 3 0
							if (omokpan[y][x] == 0 && omokpan[y - 4][x] == 0) {
								omokpanValue[y - 4][x] += 1000;

							}
						}
						if (y + 1 <= 14) { // 3 0 1 0
							if (y + 2 <= 14) {
								if (omokpan[y][x] == 0 && omokpan[y + 1][x] == userTurn
										&& omokpan[y + 2][x] != userTurn) {
									omokpanValue[y][x] += 3000;
								}
							} else {
								if (omokpan[y][x] == 0 && omokpan[y + 1][x] == userTurn) {
									omokpanValue[y][x] += 3000;
								}
							}
						}
					}
					if (count == 2) {
						if (y + 2 <= 14) { // 2 0 2
							if (omokpan[y + 1][x] == userTurn && omokpan[y + 2][x] == userTurn) {
								omokpanValue[y][x] += 3000;
							}
						}
						if (y + 1 <= 14) { // 0 2 0 1
							if (omokpan[y][x] == 0 && omokpanValue[y + 1][x] == userTurn) {
								if(y-count-1>=0 && omokpan[y-count-1][x]==0)
								omokpanValue[y][x] += 1000;
							}
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 디펜스 Y Reverse
	 */
	public void AIDefenceYReverse() {
		int x;
		int y;
		int count;
		for (x = 0; x < omokpan.length; x++) {//
			count = 1;
			for (y = omokpan.length - 1; y >= 0; y--) {
				if (omokpan[y][x] == userTurn && y != 14) {// x가 14가 아니며, 검은 돌이 있을 때
					if (omokpan[y + 1][x] == omokpan[y][x]) { // 이전 돌도 검은 색일 때
						count += 1;
					} else { // 이전 돌과 색이 다르거나 x가 0일 때
						count = 1;
					}
					if (y == 0) { // 끝에가면 초기화
						count = 1;
					}
				} else if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
					count = 1;
				} else { // 연쇄가 끊겼을 때(돌이 없을 때)
					if(count>=2) {
						System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceYReverse");
						}
					if (count == 4) {
						if (y >= 0 && omokpan[y][x] == 0) {
							if(y-1<=14&&AITurn==-2&&omokpan[y-1][x]==userTurn) { // 백일 때 6목이면 안 막음
							} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
							omokpanValue[y][x] += 3000;
							}
						}
					}
					if (count == 3) { // 3 연쇄일 경우
						if (y + 4 <= 14 && y >= 0) { // 0 3 0
							if (omokpan[y][x] == 0 && omokpan[y + 4][x] == 0) {
								omokpanValue[y + 4][x] += 1000;
							}
						}
						if (y - 1 >= 0) { // 3 0 1 0
							if (y - 2 >= 0) {
								if (omokpan[y][x] == 0 && omokpan[y - 1][x] == userTurn
										&& omokpan[y - 2][x] != userTurn) {
									omokpanValue[y][x] += 3000;
								}
							} else {
								if (omokpan[y][x] == 0 && omokpan[y - 1][x] == userTurn) {
									omokpanValue[y][x] += 3000;
								}
							}
						}
					}
					if (count == 2) {
						if (y - 2 >= 0) { // 2 0 2
							if (omokpan[y - 1][x] == userTurn && omokpan[y - 2][x] == userTurn) {
								omokpanValue[y][x] += 3000;
							}
						}
						if (y - 1 >= 0) { // 0 2 0 1
							if (omokpan[y][x] == 0 && omokpan[y - 1][x] == userTurn) {
								if(y+count+1<=14 && omokpan[y+count+1][x]==0)
								omokpanValue[y][x] += 1000;
							}
						}
					}
					count = 1;
				}
			}
		}
	}

	/**
	 * AI 디펜스 왼쪽 대각선
	 */
	public void AIDefenceLeftDown() {
		int x;
		int y;
		int count = 1;
		for (int spin = 0; spin < 29; spin++) {
			for (y = 0; y < omokpan.length; y++) {
				x = spin - y;
				if (x >= 0 && x < omokpan.length) {// 15x15 내일 때
					if (y - 1 >= 0 && x + 1 < omokpan.length) {// x나 y가 0이 아닐 때
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x + 1]) {// 이전 돌도 검은 색일 때
								count += 1;
							} else { // 이전 돌이 흰 색일 때
								count = 1;
							}
							if (spin <= 14 && x == 0) {
								count = 1;
							} else if (spin > 14 && y == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) {// 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceLeftDown");
								}
							if (count == 4) {
								if (y <= 14 && x >= 0 && omokpan[y][x] == 0) {
									if(y+1<=14&&x-1>=0&&AITurn==-2&&omokpan[y+1][x-1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y - 4 >= 0 && y <= 14 && x + 4 <= 14 && x >= 0) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y - 4][x + 4] == 0) {
										omokpanValue[y - 4][x + 4] += 1000;
									}
								}
								if (y + 1 <= 14 && x - 1 >= 0) { // 3 0 1 0
									if (y + 2 <= 14 && x - 2 >= 0) {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x - 1] == userTurn
												&& omokpan[y + 2][x - 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x - 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x - 2 >= 0 && y + 2 <= 14) { // 2 0 2
									if (omokpan[y + 1][x - 1] == userTurn && omokpan[y + 2][x - 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x - 1 >= 0 && y + 1 <= 14) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y + 1][x - 1] == userTurn) {
										if(y-count-1>=0 && x+count+1<=14 && omokpan[y-count-1][x+count+1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 디펜스 왼쪽 대각선 Reverse
	 */
	public void AIDefenceLeftDownReverse() {
		int x;
		int y;
		int count = 1;
		for (int spin = 0; spin < 29; spin++) {
			y = 15;
			for (x = omokpan.length - 1 - spin; x <= 14; x++) {
				y--;
				if (x >= 0 && x < omokpan.length && y >= 0 && y < omokpan.length) {// 15x15 내일 때
					if (y + 1 <= 14 && x - 1 >= 0) {
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x - 1]) { // 이전 돌도 검은 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (spin <= 14 && x == 14) {
								count = 1;
							} else if (spin > 14 && y == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceLeftDownReverse");
								}
							if (count == 4) {
								if (y >= 0 && x <= 14 && omokpan[y][x] == 0) {
									if(y-1>=0&&x+1<=14&&AITurn==-2&&omokpan[y-1][x+1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y + 4 <= 14 && x - 4 >= 0) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y + 4][x - 4] == 0) {
										omokpanValue[y + 4][x - 4] += 1000;
									}
								}
								if (y - 1 >= 0 && x + 1 <= 14) { // 3 0 1 0
									if (y - 2 >= 0 && x + 2 <= 14) {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x + 1] == userTurn
												&& omokpan[y - 2][x + 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x + 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x + 2 <= 14 && y - 2 >= 0) { // 2 0 2
									if (omokpan[y - 1][x + 1] == userTurn && omokpan[y - 2][x + 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x + 1 <= 14 && y - 1 >= 0) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y - 1][x + 1] == userTurn) {
										if(y+count+1<=14 && x-count-1>=0 && omokpan[y+count+1][x-count-1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
			}
		}
	}

	/**
	 * AI 디펜스 오른쪽 대각선
	 */
	public void AIDefenceRightDown() {
		int x;
		int y;
		int SPIN;
		int count = 1;
		for (SPIN = 0; SPIN < 15; SPIN++) {
			y = 0;
			for (x = 14 - SPIN; x <= 14; x++) {
				if (y >= 0 && y <= SPIN) { // 15x15 내일 때
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) { // 이전 돌도 검은 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (x == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceRightDown");
								}
							if (count == 4) {
								if (y <= 14 && x <= 14 && omokpan[y][x] == 0) {
									if(y+1<=14&&x+1<=14&&AITurn==-2&&omokpan[y+1][x+1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y - 4 >= 0 && x - 4 >= 0) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y - 4][x - 4] == 0) {
										omokpanValue[y - 4][x - 4] += 1000;
									}
								}
								if (y + 1 <= 14 && x + 1 <= 14) { // 3 0 1 0
									if (y + 2 <= 14 && x + 2 <= 14) {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn
												&& omokpan[y + 2][x + 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x + 2 <= 14 && y + 2 <= 14) { // 2 0 2
									if (omokpan[y + 1][x + 1] == userTurn && omokpan[y + 2][x + 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x + 1 <= 14 && y + 1 <= 14) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn) {
										if(y-count-1>=0 && x-count-1>=0 && omokpan[y-count-1][x-count-1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
				y++;
			}
		}

		for (SPIN = 1; SPIN < 15; SPIN++) {
			count = 1;
			y = SPIN;
			for (x = 0; x <= 14 - SPIN; x++) {
				if (y >= 1 && y <= 14) {
					if (y - 1 >= 0 && x - 1 >= 0) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y - 1][x - 1]) {
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (y == 14) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceRightDown");
								}
							if (count == 4) {
								if (y <= 14 && x <= 14 && omokpan[y][x] == 0) {
									if(y+1<=14&&x+1<=14&&AITurn==-2&&omokpan[y+1][x+1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y - 4 >= 0 && x - 4 >= 0) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y - 4][x - 4] == 0) {
										omokpanValue[y - 4][x - 4] += 1000;
									}
								}
								if (y + 1 <= 14 && x + 1 <= 14) { // 3 0 1 0
									if (y + 2 <= 14 && x + 2 <= 14) {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn
												&& omokpan[y + 2][x + 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x + 2 <= 14 && y + 2 <= 14) { // 2 0 2
									if (omokpan[y + 1][x + 1] == userTurn && omokpan[y + 2][x + 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x + 1 <= 14 && y + 1 <= 14) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y + 1][x + 1] == userTurn) {
										if(y-count-1>=0 && x-count-1>=0 && omokpan[y-count-1][x-count-1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
				y++;
			}
		}
	}

	/**
	 * AI 디펜스 오른쪽 대각선 Reverse
	 */
	public void AIDefenceRightDownReverse() {
		int x;
		int y;
		int SPIN;
		int count = 1;
		for (SPIN = 0; SPIN < 15; SPIN++) {
			x = SPIN;
			for (y = 14; y >= 0; y--) {
				if (x >= 0) { // 15x15 내일 때
					if (y + 1 <= 14 && x + 1 <= 14) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x + 1]) { // 이전 돌도 검은 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (x == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceRightDownReverse");
								}
							if (count == 4) {
								if (y >= 0 && x >= 0 && omokpan[y][x] == 0) {
									if(y-1>=0&&x-1>=0&&AITurn==-2&&omokpan[y-1][x-1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y + 4 <= 14 && x + 4 <= 14) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y + 4][x + 4] == 0) {
										omokpanValue[y + 4][x + 4] += 1000;
									}
								}
								if (y - 1 >= 0 && x - 1 >= 0) { // 3 0 1 0
									if (y - 2 >= 0 && x - 2 >= 0) {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn
												&& omokpan[y - 2][x - 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x - 2 >= 0 && y - 2 >= 0) { // 2 0 2
									if (omokpan[y - 1][x - 1] == userTurn && omokpan[y - 2][x - 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x - 1 >= 0 && y - 1 >= 0) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn) {
										if(y+count+1<=14 && x+count+1<=14 && omokpan[y+count+1][x+count+1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
				x--;
			}
		}

		for (SPIN = 1; SPIN < 15; SPIN++) {
			y = 14 - SPIN;
			for (x = 14; x >= 0; x--) {
				if (y >= 0) { // 15x15 내일 때
					if (y + 1 <= 14 && x + 1 <= 14) { // x나 y가 0이 아닐 때
						if (omokpan[y][x] == userTurn) { // 검은 돌이 있을 때
							if (omokpan[y][x] == omokpan[y + 1][x + 1]) { // 이전 돌도 검은 색일 때
								count += 1;
							} else { // 이전 돌과 색이 다를 때
								count = 1;
							}
							if (y == 0) {
								count = 1;
							}
						} else if (omokpan[y][x] == AITurn) { // 흰 돌이 있을 때
							count = 1;
						} else { // 연쇄가 끊겼을 때(돌이 없을 때)
							if(count>=2) {
								System.out.println("x==> "+x+" y==> "+y+" count==> "+count+" method==> AIDefenceRightDownReverse");
								}
							if (count == 4) {
								if (y >= 0 && x >= 0 && omokpan[y][x] == 0) {
									if(y-1>=0&&x-1>=0&&AITurn==-2&&omokpan[y-1][x-1]==userTurn) { // 백일 때 6목이면 안 막음
									} else { // 마지막칸이거나 유저가 백돌이거나 6목이 아닐 때
									omokpanValue[y][x] += 3000;
									}
								}
							}
							if (count == 3) { // 3 연쇄일 경우
								if (y + 4 <= 14 && x + 4 <= 14) { // 0 3 0
									if (omokpan[y][x] == 0 && omokpan[y + 4][x + 4] == 0) {
										omokpanValue[y + 4][x + 4] += 1000;
									}
								}
								if (y - 1 >= 0 && x - 1 >= 0) { // 3 0 1 0
									if (y - 2 >= 0 && x - 2 >= 0) {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn
												&& omokpan[y - 2][x - 2] != userTurn) {
											omokpanValue[y][x] += 3000;
										}
									} else {
										if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn) {
											omokpanValue[y][x] += 3000;
										}
									}
								}
							}
							if (count == 2) {
								if (x - 2 >= 0 && y - 2 >= 0) { // 2 0 2
									if (omokpan[y - 1][x - 1] == userTurn && omokpan[y - 2][x - 2] == userTurn) {
										omokpanValue[y][x] += 3000;
									}
								}
								if (x - 1 >= 0 && y - 1 >= 0) { // 0 2 0 1
									if (omokpan[y][x] == 0 && omokpan[y - 1][x - 1] == userTurn) {
										if(y+count+1<=14 && x+count+1<=14 && omokpan[y+count+1][x+count+1]==0)
										omokpanValue[y][x] += 1000;
									}
								}
							}
							count = 1;
						}
					}
				}
				y--;
			}
		}
	}

	/**
	 * 필드 읽고 이미 놓여진 돌에 - 표기하기
	 */
	public void minusSet() {
		for (int y = 0; y < omokpan.length; y++) {
			for (int x = 0; x < omokpan.length; x++) {
				if (omokpan[y][x] == -1)
					omokpanValue[y][x] = -1;
				if (omokpan[y][x] == -2)
					omokpanValue[y][x] = -2;
			}
		}
	}

	/**
	 * 점수 출력 메소드
	 */
	public void printValue() {
		for (int y = 0; y < omokpanValue.length; y++) {
			for (int x = 0; x < omokpanValue.length; x++) {
				if (omokpanValue[y][x] < 0) { // -1, -2 (두자리)
					System.out.print(omokpanValue[y][x] + "   ");
				} else if (omokpanValue[y][x] <= 9 && omokpanValue[y][x] >= 0) { // 1~9 (한자리)
					System.out.print(omokpanValue[y][x] + "    ");
				} else if (omokpanValue[y][x] <= 99 && omokpanValue[y][x] >= 10) { // 10~99 (두자리)
					System.out.print(omokpanValue[y][x] + "   ");
				} else if (omokpanValue[y][x] <= 999 && omokpanValue[y][x] >= 100) { // 100~999 (세자리)
					System.out.print(omokpanValue[y][x] + "  ");
				} else { // 네자리 이상
					System.out.print(omokpanValue[y][x] + " ");
				}
			}
			System.out.println();
		}
	}

	/**
	 * 삼삼 체크메소드 - 미완성 렌주 룰 예정?
	 */

	/**
	 * AI 삼삼 가중치 추가
	 */

	/**
	 * 사용자가 3개 됐을 때 디펜스 하기
	 */

}
