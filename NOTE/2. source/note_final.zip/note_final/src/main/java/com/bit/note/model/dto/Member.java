package com.bit.note.model.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {
	
	private String email;
	private String pw;
	private String nickName;
	private Date accountDate;
	private byte[] profile;
	private int rating;
	private int win;
	private int lose;
	
}
