package com.bit.note.model.dao;

import java.sql.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.bit.note.model.dto.GameRoom;
import com.bit.note.model.dto.Member;

@Mapper
public interface GameRoomMapper {
	
    @Insert("INSERT INTO GAMEROOM(roomNumber, roomName, roomPW, host, status) VALUES (#{roomNumber}, #{roomName}, #{roomPW}, #{host}, #{status})")
    void create(int roomNumber, String roomName, String roomPW, String host, String status);
    
    @Select("SELECT COUNT('ROOMNUMBER') FROM GAMEROOM")
    int count();
    
    @Update("Update GAMEROOM g set g.guest=#{guest} where g.roomNumber=#{roomNumber}")
	void update(int roomNumber, String guest);
    
    @Select("SELECT * FROM ( SELECT * FROM GAMEROOM WHERE STATUS='open' order by roomnumber DESC )")
    List<GameRoom> gameroom();
    
    @Select("SELECT host FROM GAMEROOM where roomNumber = #{roomNumber}")
    String getHost(int roomNumber);
    
    @Select("SELECT guest FROM GAMEROOM where roomNumber = #{roomNumber}")
    String getGuest(int roomNumber);
    
    @Select("SELECT guest from GAMEROOM where roomNumber = #{roomNumber}")
    String guestOrNot(int roomNumber);
    
    @Select("SELECT * FROM ( SELECT * FROM GAMEROOM WHERE STATUS='open' order by roomnumber DESC ) WHERE ROOMNAME LIKE  '%' || #{ROOMNAME} || '%'" )
    List<GameRoom> searchRoom(String roomName);
    
    @Update("Update GAMEROOM g set g.status='close' where g.roomNumber=#{intNumber}")
	void roomClose(int intNumber);
}
