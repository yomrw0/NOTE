package com.bit.note.model.dao;

import java.sql.Date;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.bit.note.model.dto.Notice;

@Mapper
public interface NoticeMapper {
   
   @Select("SELECT * FROM notice")
   List<Notice> noticeList();
   
   @Insert("INSERT INTO notice(title, writer, contents, writedate, noticeNumber) VALUES (#{title}, 'ADMIN', #{contents}, #{writeDate}, #{noticeNumber})")
   void insertNotice(String title, String contents, Date writeDate, int noticeNumber);
   
   @Update("UPDATE notice n SET n.title=#{title}, n.contents=#{contents} WHERE n.noticeNumber=#{noticeNumber}")
   void updateNotice (String title, String contents, int noticeNumber);
   
   @Delete("DELETE FROM notice WHERE noticeNumber=#{noticeNumber}")
   void deleteNotice (int noticeNumber);
   
   @Select("SELECT * From notice WHERE noticeNumber=#{noticeNumber}")
   Notice listNotice(int noticeNumber);
   
   @Select("SELECT COUNT('NOTICENUMBER') FROM notice")
   int count();
}