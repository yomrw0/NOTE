const qs = selector => document.querySelector(selector);
const board = document.getElementsByClassName("board")[0];

var roomNumberT = $("#roomNumber").val();
var turn;
var userTurn;
var AITurnVar;
var gameEnd;
var gameEnd = false;

qs("#cancelBtn > p > img").addEventListener('click', () => {
	location.href = "/lobby";
});


if ($("#hostStone").val() == "black") {
	turn = -1;
	userTurn = -1;
	AITurnVar = -2;
	alert("흑돌, 선제공격입니다. 돌을 놓아주세요.");
	setTurn();
} else {
	turn = -1;
	userTurn = -2;
	AITurnVar = -1;
	setTurn();
	setTimeout(function () {
		AITurn();
	}, 1000);
}

/*
 * 겜 끝났나 체크
 */

function endCheck(paramTurn) {
	console.log("end Checking...");
	console.log("체크하는 턴(-1, 흑 -2, 백)===>" + paramTurn);
	var msg = "AI" + roomNumberT;
	$.ajax({
		type: "POST",
		url: "/endCheck",
		data: { msg: msg },
		success: function (res) {
			console.log("체크결과==>" + res);
			console.log("현재 턴==>" + turn);
			if (res == true) {
				if (paramTurn == -1) {
					alert("게임 종료!! 흑돌의 승리!");
					gameEnd = true;
				} else if (paramTurn == -2) {
					alert("게임 종료!! 백돌의 승리!");
					gameEnd = true;
				}
			} else {
				gameEnd = false;
			}

		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			alert("fail");
		}
	});
}

function field2() {
	var boardInner = document.getElementsByClassName("inner")
	var srcIndex = 0;
	var msg = "AI" + roomNumberT;
	$.ajax({
		type: "POST",
		url: "/field",
		data: { msg: msg },
		success: function (res) {
			for (var y = 0; y < res.length; y++) {
				for (var x = 0; x < res[y].length; x++) {
					if (res[y][x] == -1) {
						boardInner[srcIndex].src = '../img/black.png';
					} else if (res[y][x] == -2) {
						boardInner[srcIndex].src = '../img/white.png'
					} else if (y == 0 && x == 0) {
						boardInner[srcIndex].src = '../img/y0x0.png';
					} else if (y == 0 && x >= 1 && x <= 13) {
						boardInner[srcIndex].src = '../img/y0.png';
					} else if (y == 0 && x == 14) {
						boardInner[srcIndex].src = '../img/y0x14.png';
					} else if (y == 14 && x == 14) {
						boardInner[srcIndex].src = '../img/y14x14.png';
					} else if (y == 14 && x == 0) {
						boardInner[srcIndex].src = '../img/y14x0.png';
					} else if (y == 14 && x >= 1 && x <= 13) {
						boardInner[srcIndex].src = '../img/y14.png';
					} else if (y >= 1 && y <= 13 && x == 0) {
						boardInner[srcIndex].src = '../img/x0.png';
					} else if (y >= 1 && y <= 13 && x == 14) {
						boardInner[srcIndex].src = '../img/x14.png';
					} else if ((y == 3 && x == 3) || (y == 3 && x == 11) || (y == 7 && x == 7) || (y == 11 && x == 3) || (y == 11 && x == 11)) {
						boardInner[srcIndex].src = '../img/5배수.png';
					} else {
						boardInner[srcIndex].src = '../img/십자가.png';
					}
					srcIndex = srcIndex + 1;
				}
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			alert("field2() fail");
		}
	});
}

var $inner = $('.inner').on('click', function () {
	if (gameEnd != true && userTurn != null) {
		if (turn == userTurn) {
			var idx = $inner.index(this) + "$" + turn;
			idx += "$" + "AI" + roomNumberT;
			console.log(idx);
			$.ajax({
				type: "POST",
				url: "/panclick",
				data: { idx: idx },
				success: function (res) {
					//console.log(res);
					if (res != "") {
						turn = AITurnVar;
						endCheck(userTurn);

						setTimeout(function () {
							if (gameEnd == false) {
								AITurn();
							}
						}, 1000);
						field2();
					} else {
						alert("이미 돌이 놓여진 위치입니다. 다른 위치를 선택해주세요");
					}
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					alert("fail");
				}
			});
		} else { // AI 턴이라 조작불가
			alert("ai가 생각하는 중입니다...");
		}
	} else if (userTurn == null) {
		alert("게임이 시작되지 않았습니다. 돌을 선택해주세요.");
	} else {
		alert("게임이 끝났어요!");
	};
});

function AITurn() {
	var msg = AITurnVar + ",AI" + roomNumberT;
	console.log("ai가 생각하는 중...");
	if (gameEnd != true) {
		$.ajax({
			type: "POST",
			url: "/AITurn",
			data: { msg: msg },
			success: function (res) {
				for (var i = 0; i < res.length; i++) {
					console.log(res[i] + "  " + i);
				}
				field2();
				endCheck(AITurnVar);
				turn = userTurn;
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
				alert("fail");
			}
		});
	}
}

function setTurn() {
	var msg = userTurn + "," + AITurnVar;
	msg += "," + "AI" + roomNumberT;
	console.log(msg);
	$.ajax({
		type: "POST",
		url: "/register",
		data: { msg: msg },
		success: function (res) {
			console.log("set Turn success");
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			alert("fail");
		}
	});

}