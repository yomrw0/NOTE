const qs = selector => document.querySelector(selector);

let emailChecked = false;
let nickNameChecked = false;

$('#emailCheck').click(function () {
	const email = $('#email').val();
	if (email == "") {
		$('#checkMsg').html('<p style="color:black">이메일을 입력해주세요</p>');
		emailChecked = false;
	} else if (!CheckEmail(email)) {
		alert("올바르지 않은 유형입니다.");
		emailChecked = false;
	}
	else {
		$.ajax({
			type: 'POST',
			url: 'emailCheck',
			data: { "email": email },
			success: function (data) {
				if ($.trim(data) == 0) {
					$('#checkMsg').html('<p style="color:blue">사용가능한 이메일입니다</p>');
					emailChecked = true;
				} else {
					$('#checkMsg').html('<p style="color:red">이미 회원가입된 이메일입니다</p>');
					emailChecked = false;
				}
			}
		});
	}
});

function CheckEmail(str) {
	const reg_email = /^([0-9a-zA-Z_\.-]+)@([0-9a-zA-Z_-]+)(\.[0-9a-zA-Z_-]+){1,2}$/;
	if (!reg_email.test(str)) {
		return false;
	}
	else {
		return true;
	}
}

$('#nickNameCheck').click(function () {
	var nickName = $('#nickName').val();
	if (nickName == "") {
		$('#checkMsg2').html('<p style="color:black">닉네임을 입력해주세요</p>');
		nickNameChecked = false;
	} else {
		$.ajax({
			type: 'POST',
			url: 'nickNameCheck',
			data: { "nickName": nickName },
			success: function (data) {
				if ($.trim(data) == 0) {
					$('#checkMsg2').html('<p style="color:blue">사용가능한 닉네임입니다</p>');
					nickNameChecked = true;
				} else {
					$('#checkMsg2').html('<p style="color:red">이미 등록된 닉네임입니다</p>');
					nickNameChecked = false;
				}
			}
		});
	}
});

$("form").submit(function () {
	if (fr.email.value == "") {
		alert("이메일을 입력해 주세요.");
		fr.email.focus();
		return false;
	} else if (emailChecked == false) {
		alert("이메일 중복확인을 해주세요.");
		return false;
	}

	else if (fr.pw.value == "") {
		alert("비밀번호를 입력해 주세요.");
		fr.pw.focus();
		return false;
	}

	else if (fr.nickName.value == "") {
		alert("닉네임을 입력해 주세요.");
		fr.nickName.focus();
		return false;
	} else if (nickNameChecked == false) {
		alert("닉네임 중복확인을 해주세요.");
		return false;
	}

	else if (fr.file.value == "") {
		alert("프로필을 등록해 주세요.");
		fr.file.focus();
		return false;
	} else {
		return true;
	}
});

qs("#back").addEventListener('click', () => {
	location.href = "/";
})

