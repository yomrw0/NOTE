const qs = selector => document.querySelector(selector);

const rulesBtn = qs(".column_1 > button:nth-child(1)");
const mainBtn = qs(".column_1 > button:nth-child(2)");
const noticeBtn = qs(".column_1 > button:nth-child(3)");

const createRoom = qs(".createRoom");
const rules = qs(".rules");
const rule = qs(".rule");
const way = qs(".way");
const etc = qs(".etc");
const bg = qs("#BG");

rulesBtn.addEventListener('click', () => {
    rules.style.display = "flex";
    bg.style.display = "flex";
    rule.style.display = "block";
});

mainBtn.addEventListener('click', () => {
    location.href = "/";
});

noticeBtn.addEventListener('click', () => {
    location.href = "/noticeList";
});


qs("#create").addEventListener('click', () => {
    createRoom.style.display = "flex";
    bg.style.display = "flex";
});

qs("#cancelBtn").addEventListener('click', () => {
    createRoom.style.display = "none";
    bg.style.display = "none";
});

qs("#prevBtn > p:nth-child(2)").addEventListener('click', () => {
    rules.style.display = "none";
    bg.style.display = "none";
});

qs(".left > button:nth-child(1)").addEventListener('click', () => {
    rule.style.display = "block";
    way.style.display = "none";
    etc.style.display = "none";
});

qs(".left > button:nth-child(2)").addEventListener('click', () => {
    rule.style.display = "none";
    way.style.display = "block";
    etc.style.display = "none";
});

qs(".left > button:nth-child(3)").addEventListener('click', () => {
    rule.style.display = "none";
    way.style.display = "none";
    etc.style.display = "block";
});


$("#createRoomBtn").click(function () {
    if (createForm.title.value == "") {
        alert("방 제목을 입력해주세요.");
        createForm.title.focus();
    } else if ($('#lockCheck').is(':checked') == true && createForm.password.value == "") {
        alert("비밀번호를 입력해주세요.");
        createForm.password.focus();
    } else if ($('#lockCheck').is(':checked') == false && createForm.password.value != "" && createForm.password.value != null) {
        alert("잠금 설정을 해주세요.");
    } else {
        $('#createForm').submit();
    }
});

var ws;
var messages = document.getElementById("messages");
var msg;
var send = document.getElementById("send");

function openSocket() {
    if (ws !== undefined && ws.readyState !== WebSocket.CLOSED) {
        writeResponse("WebSocket is already opened.");
        return;
    }
    //웹소켓 객체 만드는 코드
    ws = new WebSocket("ws://192.168.0.5:9090/lobby")

    ws.onopen = function (event) {
        if (event.data === undefined) {
            return;
        }
        writeResponse(event.data);
    };

    ws.onmessage = function (event) {
        if (event.data == "give*Me*Nick") {
            ws.send($("#sender").val() + ",ConnectIn");
        } else if (event.data.split(",")[0] == "ConnNick") {
            var connListSize = event.data.split(",")[1]
            var connectorDiv = document
                .getElementsByClassName("connector");
            connectorDiv[0].innerHTML = "<h1>Connector</h1>";
            connectorDiv[0].innerHTML += "<p>nickName</p>";
            console.log("size==" + connListSize);
            for (var i = 2; i < 2 + connListSize; i++) {
                if (event.data.split(",")[i] != ""
                    && event.data.split(",")[i] != undefined) {
                    if (i - 2 <= 8)
                        connectorDiv[0].innerHTML += '<p>'
                            + event.data.split(",")[i] + '</p>';
                }
            }
        } else {
            console.log('writeResponse');
            console.log(event.data)
            writeResponse(event.data);
            $("#messages").scrollTop(messages.scrollHeight);
        }
    };

    ws.onclose = function (event) {
        writeResponse("대화 종료");
    }

    /*
     * 엔터쳐도 전송되게 하는 기능
     */
    document.addEventListener("keypress", function (e) {
        if (e.keyCode == 13) { //enter press
            var text = document.getElementById("messageinput").value
                + "," + document.getElementById("sender").value;
            ws.send(text);

            msg = $("#messageinput").val();
            console.log(msg);

            text = "";
            $('#messageinput').val("");
        }
    });

    send.addEventListener("click", function (e) {
        var text = document.getElementById("messageinput").value + ","
            + document.getElementById("sender").value;
        ws.send(text);

        msg = $("#messageinput").val();
        console.log(msg);

        text = "";
        $('#messageinput').val("");
    });
}

function send() {
    var text = document.getElementById("messageinput").value + ","
        + document.getElementById("sender").value;
    ws.send(text);

    msg = $("#messageinput").val();
    console.log(msg);

    text = "";
    $('#messageinput').val("");
}

function closeSocket() {
    ws.close();
}

/*
 * 웹소켓 서버랑 별개로 html에 채팅 적는 기능
 */
function writeResponse(text) {
    messages.innerHTML += "<br/>" + text;
}

window.onload = function () {
    openSocket();
}

var $gameRoom = $('.gameRoom').on(
    'click',
    function () {
        var idx = $gameRoom.index(this);
        var $gameRoomNumber = $(".gameRoomNumber").eq(idx).text();
        $.ajax({
            type: "POST",
            url: "/guestOrNot",
            data: {
                $gameRoomNumber: $gameRoomNumber
            },
            success: function (res) {
                if (res == true) {
                    location.href = "/omokGuest?roomNumber="
                        + $gameRoomNumber;
                } else {
                    alert("인원수가 가득 찼습니다.");
                    location.href = "/lobby"
                }
            },
            error: function (XMLHttpRequest, textStatus,
                errorThrown) {
                alert("fail");
            }
        });

    });

var btn_search1 = document.getElementById("btn_search");
var roomword1 = document.getElementById("roomword");

btn_search1.addEventListener('click', function () {
    search(roomword1.value);
});

function search() {
    $("#btn_search")
        .click(
            function () {
                var roomword = $("#roomword").val();
                if (roomword != '') {
                    //start Ajax
                    $
                        .ajax({
                            type: 'POST',
                            url: "/search",
                            data: {
                                roomword: roomword
                            },
                            success: function (result) {
                                console.log(result);
                                if (result.length > 0) {
                                    var str = ''
                                    for (var i = 0; i < result.length; i++) {
                                        str += '<img src="img/omok.ico">';
                                        str += '<div class="gameRoom">';
                                        str += '<p class="gameRoomNumber" th:text="' + result[i].roomNumber + '">'
                                            + result[i].roomNumber
                                            + '</p>';
                                        if (result[i].roomPw != null
                                            || result[i].roomPw != '') {
                                            str += '<img src="img/lock.png">';
                                        } else {
                                            str += '<img src="img/nonlock.png">';
                                        }
                                        str += '<p th:text="' + result[i].roomName + '">'
                                            + result[i].roomName
                                            + '</p>';
                                        if (result[i].guest == 'AI') {
                                            str += '<p>omok AI</p>';
                                        } else {
                                            str += '<p>omok</p>';
                                        }
                                        if (result[i].guest == null
                                            || result[i].guest == '') {
                                            str += '<p class="gameRoomGuestOrNot">인원수 1/2</p>';
                                        } else {
                                            str += '<p class="gameRoomGuestOrNot">인원수 2/2</p>';
                                        }
                                        str += '</div>';
                                    }
                                    var searchResults = document
                                        .getElementById('results');
                                    searchResults.innerHTML = str;
                                }
                            },
                            error: function (err) {
                                console
                                    .log("실행중 오류가 발생하였습니다.");
                            }
                        });
                }
            });
}