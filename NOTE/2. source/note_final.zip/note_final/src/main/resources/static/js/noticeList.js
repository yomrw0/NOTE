const qs = selector => document.querySelector(selector);

const container = qs('#container');
const notice = qs("#notice");

qs(".createNotice").addEventListener('click', () => {
	container.style.display = "none";
	notice.style.display = "flex";
	$("#update").css("display", "none");
	$("#delete").css("display", "none");
	$("#insert").css("display", "block");

});

qs(".title > p").addEventListener('click', () => {
	container.style.display = "flex";
	notice.style.display = "none";
	$('#titleArea').text('');
	$('#contentsArea').text('');
	$('#NoticeNum').val('');
});

qs("#cancelBtn > p > img").addEventListener('click', () => {
	location.href = "/lobby";
});

var $th = $('.list').on('click', function(){
	var idx = $th.index(this)
	var td = $(".list:eq("+idx+")").children().eq(0).text();
	 $.ajax({
		  type : "POST",  
		  url : "/connect",    
		  data : { td : td },
		  success : function(res){
				container.style.display = "none";
				 notice.style.display = "flex";
				 $("#update").css("display", "block");
				$("#delete").css("display", "block");
				$("#insert").css("display", "none");
				$('#titleArea').text(res.title);
				$('#contentsArea').text(res.contents);  
				$('#noticeNum').val(res.noticeNumber);
		  },
		  error : function(XMLHttpRequest, textStatus, errorThrown){
			 console.log(XMLHttpRequest);
			 console.log(textStatus);
			 console.log(errorThrown);
			 alert("error");
		  }
   });
});