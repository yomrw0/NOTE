const qs = selector => document.querySelector(selector);
const qsa = selector => document.querySelectorAll(selector);

var board = document.getElementsByClassName("board")[0];
var btnExam2 = document.getElementById("btnExam2");
var turnCheck = document.getElementById("turnCheck");
var hostStone = document.getElementById("hostStone");
var turn;
var hostTurn;
var guestTurnVar;
var gameEnd;

var gameEnd = false;
openSocket();

qs("#cancelBtn > p > img").addEventListener('click', () => {
    location.href = "/lobby";
});

/*
 * 겜 끝났나 체크
 */
function endCheck(paramTurn) {
    console.log("end Checking...");
    console.log("체크하는 턴(-1, 흑 -2, 백)===>" + paramTurn);
    if (hostStone.value != "") {
        var msg = "-1" + roomNumberT;
    } else {
        var msg = "-2" + roomNumberT;
    }
    $.ajax({
        type: "POST",
        url: "/endCheck",
        data: { msg: msg },
        success: function (res) {
            console.log("체크결과==>" + res);
            console.log("현재 턴==>" + turn);
            ws.send("FTC(),FTC()," + roomNumberT);
            if (res == true) {
                if (paramTurn == -1) {
                    alert("게임 종료!! 흑돌의 승리!");
                    gameEnd = true;
                    ws.send(paramTurn + "~" + hostTurn + ", gameEnd()," + roomNumberT);
                } else if (paramTurn == -2) {
                    alert("게임 종료!! 백돌의 승리!");
                    gameEnd = true;
                    ws.send(paramTurn + "~" + hostTurn + ", gameEnd()," + roomNumberT);
                }
            } else {
                gameEnd = false;
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("fail");
        }
    });

}

function field2() {
    var boardInner = document.getElementsByClassName("inner")
    var srcIndex = 0;
    if (hostStone.value != "") {
        var msg = "-1" + roomNumberT;
    } else {
        var msg = "-2" + roomNumberT;
    }
    setTimeout(function () {
        $.ajax({
            type: "POST",
            url: "/field",
            data: { msg: msg },
            success: function (res) {
                for (var y = 0; y < res.length; y++) {
                    for (var x = 0; x < res[y].length; x++) {
                        if (res[y][x] == -1) {
                            boardInner[srcIndex].src = '../img/black.png';
                        } else if (res[y][x] == -2) {
                            boardInner[srcIndex].src = '../img/white.png'
                        } else if (y == 0 && x == 0) {
                            boardInner[srcIndex].src = '../img/y0x0.png';
                        } else if (y == 0 && x >= 1 && x <= 13) {
                            boardInner[srcIndex].src = '../img/y0.png';
                        } else if (y == 0 && x == 14) {
                            boardInner[srcIndex].src = '../img/y0x14.png';
                        } else if (y == 14 && x == 14) {
                            boardInner[srcIndex].src = '../img/y14x14.png';
                        } else if (y == 14 && x == 0) {
                            boardInner[srcIndex].src = '../img/y14x0.png';
                        } else if (y == 14 && x >= 1 && x <= 13) {
                            boardInner[srcIndex].src = '../img/y14.png';
                        } else if (y >= 1 && y <= 13 && x == 0) {
                            boardInner[srcIndex].src = '../img/x0.png';
                        } else if (y >= 1 && y <= 13 && x == 14) {
                            boardInner[srcIndex].src = '../img/x14.png';
                        } else if ((y == 3 && x == 3) || (y == 3 && x == 11) || (y == 7 && x == 7) || (y == 11 && x == 3) || (y == 11 && x == 11)) {
                            boardInner[srcIndex].src = '../img/5배수.png';
                        } else {
                            boardInner[srcIndex].src = '../img/십자가.png';
                        }
                        srcIndex = srcIndex + 1;
                    }
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("field2() fail");
            }
        });
    }, 500);
}

var $inner = $('.inner').on('click', function () {
    if (gameEnd != true && hostTurn != null) {
        if (turn == hostTurn) { // 호스트 턴
            if (hostStone.value != "") { // 호스트 턴, 호스트
                var idx = $inner.index(this) + "$" + turn;
                console.log(idx);
                ws.send(idx + ",panclick()," + roomNumberT);
            } else { // 호스트 턴, 게스트
                alert("상대가 생각하는 중입니다...");
            }

        } else if (turn == guestTurnVar) { // 게스트 턴
            if (hostStone.value != "") { // 게스트 턴, 호스트
                alert("상대가 생각하는 중입니다...");
            } else { // 게스트 턴, 게스트
                var idx = $inner.index(this) + "$" + turn;
                console.log(idx);
                ws.send(idx + ",panclick()," + roomNumberT);
            }

        }
    } else if (hostTurn == null) {
        alert("게임이 시작되지 않았습니다. 다른 유저의 입장을 기다려주세요.");
    } else {
        alert("게임이 끝났어요!");
    };
});


function setTurn() {
    var msg = hostTurn + "," + guestTurnVar;
    if (hostStone.value != "") {
        msg += "," + "-1" + roomNumberT;
    } else {
        msg += "," + "-2" + roomNumberT;
    }
    console.log(msg);
    $.ajax({
        type: "POST",
        url: "/register",
        data: { msg: msg },
        success: function (res) {
            console.log("set Turn success");
            console.log(res);
            turn = -1;
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("fail");
        }
    });

    ws.send("FTC(),FTC()," + roomNumberT);
}


/////////////////////////웹소켓///////////////////////////////////
var ws;
var messages = document.getElementById("messages");
var msg;
var roomNumberT = $("#roomNumber").val();

const member1NickTarget = document.getElementsByClassName("nick")[1];
const member1EmailTarget = document.getElementsByClassName("email")[1];
const member1WinLoseTarget = document.getElementsByClassName("record")[1];
const member1IMGTarget = document.getElementsByClassName("imagePreview")[1];

function openSocket() {
    if (ws !== undefined && ws.readyState !== WebSocket.CLOSED) {
        writeResponse("WebSocket is already opened.");
        return;
    }
    //웹소켓 객체 만드는 코드
    ws = new WebSocket('ws://192.168.0.5:9090/chat');

    ws.onopen = () => next();
}

function next() { // 웹소켓 중 "방 이름" 으로 구역을 나눠서 거기 등록하도록 명령
    console.log("roomNumberT====" + roomNumberT);
    ws.send(document.getElementById("who").value + ",offerWSset," + roomNumberT);
    nenext();
}

function nenext() {
    ws.onopen = function (event) {
        if (event.data === undefined) {
            return;
        }
        console.log(event.data);
        /* writeResponse(event.data); */
    };

    /*
    * 서버로부터 메세지받음. 내가보낸것도 받음.
    */
    ws.onmessage = function (event) {
        console.log('메세지 수신, 삐빅');
        console.log("받은 메세지==" + event.data);
        if (event.data == "blockGuest") { // 호스트 등록인가?
            const blockGuestTarget = document.getElementsByClassName("inputChat")[1];
            blockGuestTarget.disabled = true;
        } else if (event.data == "infoPlz") { // 게스트 정보 요구인가?
            const blockHostTarget = document.getElementsByClassName("inputChat")[0];
            blockHostTarget.disabled = true;
            ws.send(member1NickTarget.textContent + "~" + member1EmailTarget.textContent + "~" + member1WinLoseTarget.textContent + ",guestInfo," + roomNumberT);
        } else if (event.data.split("*")[0] == "guestInfoBack") { // 게스트 정보 반환인가?
            console.log(event.data.split("*")[1]);
            console.log(event.data.split("*")[2]);
            console.log(event.data.split("*")[3]);
            var guestBackNick = event.data.split("*")[1];
            var guestBackEmail = event.data.split("*")[2];
            var guestBackWinLose = event.data.split("*")[3];
            var guestBackIMG = 'getByteImageByEmail?email=' + event.data.split("*")[2];
            member1NickTarget.textContent = guestBackNick;
            member1EmailTarget.textContent = guestBackEmail;
            member1WinLoseTarget.textContent = guestBackWinLose;
            member1IMGTarget.src = guestBackIMG;
            if (document.getElementById("hostStone").value == "black") {
                ws.send("black,FTC(black)," + roomNumberT);
            } else if (document.getElementById("hostStone").value == "white") {
                ws.send("white,FTC(white)," + roomNumberT);
            }
        } else if (event.data == "FTC()") {
            field2();
        } else if (event.data == "FTC(black)") {
            hostTurn = -1;
            guestTurnVar = -2;
            if (hostStone.value != "") {
                alert("게임이 시작되었습니다. 흑돌입니다. 돌을 놓아주십시오.");
            } else {
                alert("게임이 시작되었습니다. 백돌입니다.");
            }
            setTurn();
        } else if (event.data == "FTC(white)") {
            hostTurn = -2;
            guestTurnVar = -1;
            if (hostStone.value != "") {
                alert("게임이 시작되었습니다. 백돌입니다.");
            } else {
                alert("게임이 시작되었습니다. 흑돌입니다. 돌을 놓아주십시오.");
            }
            setTurn();
        } else if (event.data.split("&*&")[0] == "panclick()") { // 판클릭
            var idx = event.data.split("&*&")[1];
            console.log("onmessage panclick idx == " + idx);
            if (hostStone.value != "") {
                idx += "$" + "-1" + roomNumberT;
            } else {
                idx += "$" + "-2" + roomNumberT;
            }
            setTimeout(function () {
                $.ajax({
                    type: "POST",
                    url: "/panclick",
                    data: { idx: idx },
                    success: function (res) {
                        console.log(res);
                        if (res != "") {
                            ws.send("FTC(),FTC()," + roomNumberT);
                            endCheck(turn);
                            if (turn == hostTurn) {
                                turn = guestTurnVar;
                            } else if (turn == guestTurnVar) {
                                turn = hostTurn;
                            }
                        } else {
                            if (idx.split(".")[1] == hostTurn && hostStone.value != "") {
                                alert("이미 돌이 놓여진 위치입니다. 다른 위치를 선택해주세요");
                            } else if (idx.split(".")[1] == guestTurnVar && hostStone.value != "") {
                                alert("이미 돌이 놓여진 위치입니다. 다른 위치를 선택해주세요");
                            }
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert("fail");
                    }
                });
            }, 500);
        } else if (event.data == "gameEnd()") {
            alert("상대 연결이 끊어졌어요. 게임을 종료합니다.");
            gameEnd = true;
        } else { // 정상적인 채팅
            console.log("정상적인 넘어온 채팅" + event.data);
            if (event.data.split("!@#**")[1] == "Guest") {
                writeResponseGuest(event.data.split("!@#**")[0]);
            } else if (event.data.split("!@#**")[1] == "Host") {
                writeResponseHost(event.data.split("!@#**")[0]);
            } else {
                console.log("error, host guest 식별불가");
            }
        }
    };

    ws.onclose = function (event) {
        /* writeResponse("대화 종료"); */
    }

    /*
     * 엔터쳐도 전송되게 하는 기능
     */
    document.addEventListener("keypress", function (e) {
        if (e.keyCode == 13) { //enter press
            send();
        }
    });
}

function send() {
    var text = document.getElementsByClassName("inputChat")[0].value
        + document.getElementsByClassName("inputChat")[1].value + ","
        + document.getElementById("who").value + ","
        + roomNumberT;
    ws.send(text);

    text = "";
    $('.inputChat:eq(0)').val("");
    $('.inputChat:eq(1)').val("");
}

function closeSocket() {
    ws.close();
}

/*
 * 웹소켓 서버랑 별개로 html에 채팅 적는 기능
 */
function writeResponseHost(text) {
    console.log('writeResponse');
    console.log(text);
    document.getElementsByClassName("chatOut")[0].value = text;
}

function writeResponseGuest(text) {
    console.log('writeResponse');
    console.log(text);
    document.getElementsByClassName("chatOut")[1].value = text;
}