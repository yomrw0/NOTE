const qs = selector => document.querySelector(selector);
const qsa = selector => document.querySelectorAll(selector);

qs("#googleLoginBtn").addEventListener('click', () => {
	window.location.replace('https://accounts.google.com/o/oauth2/v2/auth?client_id=299690057507-19leos8jg5jf6fak59nfrhcl4bt3tr56.apps.googleusercontent.com&redirect_uri=http://localhost:9090/success&response_type=code&scope=email%20profile%20openid&access_type=offline')
});

qsa(".signUp").forEach(e => {
	e.addEventListener('click', () => {
		location.href = "/join";
	});
});

$("#fr").submit(function () {
	if (fr.email.value == "") {
		fr.email.focus();
		return false;
	} else if (fr.pw.value == "") {
		fr.pw.focus();
		return false;
	} else {
		return true;
	}
});

